[Contents](../README.md) · [← 15. Limitations](15-limitations.md)

# 16. CAM

The **CAM** tab makes the program of a 3-axis milling machine from a saved part of the project. The tab follows the FreeCAD CAM workbench: a job holds the operations, the model with its placement, the stock, the setup sheet and the tool controllers; an operation is edited in a command window in the view with the sections **Base geometry**, **Depths**, **Heights** and **Operation**; dressups change the path of an operation; the operations are simulated on the stock; the post-processor writes the G-code file. The interface is the interface of the Part tab: a tree in the side panel, a command window in the view, faces and edges picked by clicks in the view and listed as chips.

Coordinates: the moves are computed in the job coordinates (mm, Z up): the part coordinates of the Part tab moved by the model placement ([Model placement](#model-placement)). Without a placement the job coordinates are the part coordinates. The G-code is written in machine coordinates: the job coordinates less the machine zero of the stock. Feeds in mm/min, spindle speed in 1/min.

| Control | Function |
|---|---|
| **File ▾** | **Job** list of the saved jobs of the project; **New**, **Save**, **Save as…**, **Rename…**, **Open file…**, **Save as file…** (`.sccam`); **G-code folder** (empty: the `cam/` folder of the project; no project: download); **Post-processor**; **File name** of the G-code (empty: `<job>.nc`); **Post process**, **Download G-code**, **Inspect G-code** ([section 16.7](#167-post-process)); **Export template**, **Import template…** ([section 16.8](#168-job-template)); **Open** opens the `cam/` folder |
| **Part** | The saved part the operations machine. A change of the part reloads the geometry; the operations and their geometry are kept |
| **Zero** | Machine zero at a vertex: a click on a vertex of the part in the view (the vertex nearest the cursor within 12 px is marked) sets **Machine zero X Y** and **Machine zero Z** to **Picked vertex** at that vertex. Esc cancels |
| **Placement** | Opens the **Model placement** command window ([Model placement](#model-placement)) |
| **Face**, **Profile**, **Pocket**, **Adaptive**, **Drilling**, **Helix**, **Slot**, **Undercut**, **Engrave**, **Vcarve**, **Deburr** | Toolbar buttons with icons. Adds the operation at the end of the list and opens its command window ([section 16.3](#163-operations)) |
| **3D Pocket**, **3D Surface**, **Waterline** | Toolbar buttons with icons ([section 16.4](#164-3d-operations)) |
| **Dressup ▾** | **Tag**, **Ramp entry**, **Lead in/out**, **Dogbone**, **Boundary**: adds the dressup to the selected operation and opens its command window ([section 16.5](#165-dressups)) |
| **More ▾** | **Fixture**, **Comment**, **Stop**, **Custom** (supplemental operations without a cut), **Copy**, **Array** (the moves of another operation again) ([section 16.6](#166-supplemental-copy-and-array)) |
| **Simulate** | Computes all toolpaths and cuts the stock with the tool ([section 16.7](#167-simulation-sanity-check-and-results)) |
| **Sanity check** | Checks of the job in the properties panel |
| **G-code** | G-code of the selected operation (no operation selected: the whole job) in a window, as **Inspect G-code** |
| **Iso**, **Front**, **Top**, **Right**, **Fit** | Views |
| **Show ▾** | **Edges**, **Axes**, **Part**, **Stock after the operations** (translucent blue), **Remaining material** (red: the stock outside the part after the operations, films thinner than 0.02 mm left out), **Toolpaths** (plunges blue, feed moves green, arcs violet), **Rapid moves** (orange), **Undercut faces** (tinted blue), **3D surfaces** (the cut surface of a 3D Surface operation from its height map, green) |
| **Panel** | Hides or shows the side panel (Ctrl+B) |

The side panel: **Tree** ([section 16.1](#161-job-tree)), **Properties** of the selected tree item and **Tool bits** ([section 16.2](#162-tool-bits-and-tool-controllers), folded by default). The bar between the view and the panel sets the panel width.

## 16.1 Job tree

The tree is arranged as the job tree of the FreeCAD CAM workbench:

```
Job
  Operations
    <operation>
      <dressup>
  Model
    <part>
      <placement constraint>
  Stock
  SetupSheet
  Tools
    TC1, TC2, …
```

**▸** and **▾** fold and unfold an item with children (a double click on **Job**, **Operations** or **Tools** does the same); the folded items are kept for the next session (**Tools** folded by default). The eye hides the geometry of the item in the view: **Job** everything, **Operations** all toolpaths, an operation its toolpath, **Model** the part, **Stock** the stock outline, the machine zero and the stock after the operations. A hidden item is shown grey. A click selects the item (its properties in the panel); a double click on an operation or a dressup opens its command window, on **Model**, the part or a constraint the **Model placement** window.

| Item | Properties |
|---|---|
| **Job** (the job name) | **Post-processor**, **File name**, **Folder**, **Post process**, **Download** |
| **Operations** | Number of operations and the cycle time of the last run |
| `<operation>` | The checkbox sets it active (inactive: no moves, the stock unchanged), the icon of the type, the name, the type, the tool controller, the number of faces and edges, the state after a run (✓, ⚠ gouge, ✗ error with the message), **▲** and **▼** change the order, **×** deletes it. Properties: the summary and the results of the last run; **Edit** opens the command window. A dressup is a row under its operation |
| **Model** | **Part**, its face count, volume and bounding box in job coordinates, the placement and the number of constraints; **Edit** opens the **Model placement** window |
| `<part>` | The part name and its position and rotation. The placement constraints are rows under it; **×** deletes one |
| **Stock** | **Material**: the workpiece material of the feeds and speeds calculator ([Feeds and speeds](#feeds-and-speeds)). **Stock**: **Part bounding box with offsets** (**X neg**, **X pos**, **Y neg**, **Y pos**, **Z neg**, **Z pos** in mm beyond the part bounding box), **Box (coordinates)** (**X min** to **Z max** in job coordinates; empty: the part bounding box), **Part with the undercuts filled** (the finished part with the material under every undercut face still in place, the stock an earlier program with an end mill leaves). **Machine zero X Y**: **Stock corner (min X, min Y)**, **Stock centre**, **Part origin** (the origin of the job coordinates), **Picked vertex**. **Machine zero Z**: **Stock top**, **Stock bottom (table)**, **Part origin**, **Picked vertex**. **Pick vertex** (or **Zero** in the toolbar) starts the vertex click; the picked vertex is shown in job coordinates and moves with the part when the placement changes. The line below gives the stock size, the machine zero in job coordinates and the clearance height in machine coordinates. The view shows the stock outline dashed and the machine zero as a triad |
| **SetupSheet** | The defaults of the operations: **Clearance height offset (mm)** and **Safe height offset (mm)** above the start depth, **Step down (mm)**, **Finish depth (mm)**, **Horizontal rapid (mm/min)** and **Vertical rapid (mm/min)** for the cycle time, **Coolant**. **Machine**: **Spindle min (rpm)**, **Spindle max (rpm)**, **Rated speed (rpm)**, **Spindle power (kW)**, **Max feed (mm/min)** for the feeds and speeds calculator and the sanity check |
| **Tools** | The list of the controllers; **Add from bit** and **Add controller** make a controller from a bit of the library; **Feeds and speeds for all** sets **Feed (mm/min)**, **Plunge feed (mm/min)** and **Spindle (rpm)** of every controller from the calculator with the **ae (mm)** and **ap (mm)** of each controller |
| `TC1`, `TC2`, … | A tool controller ([section 16.2](#162-tool-bits-and-tool-controllers)); **×** deletes it |

### Model placement

**Placement** in the toolbar opens the **Model placement** command window. It moves and turns the part in the job coordinate system. The XY plane of the job coordinate system is the table plane and +Z is the spindle axis. The stock, the machine zero and the operations are worked out on the placed part. While the window is open the view shows the datum planes **XY** (orange), **XZ** (green) and **YZ** (red) through the job origin.

| Section | Content |
|---|---|
| **Constraints** | **Coincident**, **Distance**, **Parallel**, **Angle**, **Concentric**: a click on the type, then a click on a face of the part, adds a constraint of that face to a datum plane or axis (the assembly mates of [section 11](11-assembly.md) with the datums fixed). The datum and **Flip** of a new constraint are set from the current position of the face: the datum plane (or axis for a cylindrical face) nearest in direction, **Flip** on when the face normal points along the datum normal. A Distance constraint starts at the current distance. Each row: the type and face number, **Datum** (**XY**, **XZ**, **YZ**, **X**, **Y**, **Z**), **Value** (Distance: mm; Angle: deg), **Flip** (the face turned the other way), **Off** (suppressed), **×** deletes it. Every change solves the constraints. A constraint that is not satisfied, or is left out after a conflict, is shown red with the reason. The faces of the constraints are orange in the view; the row under the mouse is highlighted yellow. Esc cancels a pending face click |
| **Position** | **X (mm)**, **Y (mm)**, **Z (mm)** of the part origin and **Rot X (deg)**, **Rot Y (deg)**, **Rot Z (deg)** (rotations about the fixed X, then Y, then Z axis about the part origin, before the translation). **X +90°**, **Y +90°**, **Z +90°** turn the part about a job axis through the centre of its bounding box. **Onto XY at 0, 0** moves the part so that its bounding box starts at X 0, Y 0, Z 0. **Reset** sets position and rotation to 0 and keeps the constraints. With active constraints a value typed here is the start of the next solve |

| Constraint | Face | Datum | Result |
|---|---|---|---|
| **Coincident** | Planar | Plane | The face in the datum plane; the part on the side of the datum normal (**Flip**: the other side) |
| **Coincident** | Cylindrical | Axis | The cylinder axis on the datum axis |
| **Distance** | Planar | Plane | The face parallel to the datum plane at **Value** mm |
| **Parallel** | Planar or cylindrical | Plane or axis | The face (or the cylinder axis) parallel to the datum |
| **Angle** | Planar | Plane | The face at **Value** deg to the datum plane |
| **Concentric** | Cylindrical | Axis | The cylinder axis on the datum axis |

A change of the placement moves the picked faces, edges and points of the operations with the part. Picked points (Slot) follow only a translation and a turn about Z. **OK** closes the window. **Cancel** restores the placement and the picks of the operations to their state when the window opened. A constraint keeps the centre of its face in part coordinates and finds the face again after a change of the part; a face that is no longer found is reported and the constraint left out.

## 16.2 Tool bits and tool controllers

The tool bit library is saved in `config.json` (`cam_tools`) with **Save bits**. It is the same for all projects. **Add bit** adds a row; **×** deletes it.

| Column | Content |
|---|---|
| **Id**, **Name** | Identifier of the bit and its text |
| **Shape** | **End mill**, **Ball end mill**, **Bull nose**, **V bit**, **Chamfer**, **Drill**, **Dovetail** |
| **D (mm)** | Diameter. Dovetail: the large diameter at the bottom |
| **Corner r (mm)** | Bull nose: the corner radius |
| **Angle (deg)** | Dovetail: the angle between the flank and the base plane. V bit and chamfer: the included angle. Drill: the point angle |
| **Tip (mm)** | V bit and chamfer: the diameter of the flat tip |
| **Cut. height (mm)** | Height of the cutting part. Dovetail: the height of the flank. The flank of a dovetail cutter ends at a radius of D/2 - height / tan(angle); a height that leaves no radius is refused |
| **Neck (mm)**, **Neck len. (mm)** | Diameter and length of the neck above the cutting part |
| **Shank (mm)**, **Shank len. (mm)** | Diameter and length of the shank above the neck |
| **Flutes** | Number of flutes |
| **Tool mat.** | **Carbide** or **HSS** (feeds and speeds calculator) |
| **Feed (mm/min)**, **Plunge (mm/min)**, **rpm** | The values a new tool controller takes |

The bit is a solid of revolution: the cutting part is the profile of the shape, the neck and the shank are cylinders. The cutting part cuts the stock; the neck and the shank are checked against the stock.

A tool controller is a bit with the values of the job: **Id**, **Name**, **Tool bit**, **Tool number** (the `T` number of the G-code), **Feed (mm/min)**, **Plunge feed (mm/min)**, **Spindle (rpm)**, **Direction** (**CW (M03)**, **CCW (M04)**). Operations refer to a controller. An operation added to a job without a controller for its tool shape gets one made from the first bit of that shape in the library.

| Operation | Tool shapes |
|---|---|
| Profile, Pocket Shape, Face, Helix, Adaptive | End mill, bull nose |
| Drilling | Drill, end mill |
| Slot, 3D Pocket, 3D Surface, Waterline | End mill, bull nose, ball end mill |
| Engrave | V bit, chamfer, ball end mill, end mill |
| Deburr | V bit, chamfer |
| Vcarve | V bit |
| Undercut | Dovetail |

### Feeds and speeds

The properties of a tool controller have a **Feeds and speeds** section. It uses the **Material** of the stock, the tool bit (shape, **D (mm)**, **Flutes**, **Tool mat.**, angle and tip), the **Machine** fields of the SetupSheet, **ae (mm)** (width of cut; empty: D) and **ap (mm)** (depth of cut; empty: the step down of the SetupSheet). The result is shown on every change; **Apply** writes **Spindle (rpm)**, **Feed (mm/min)** and **Plunge feed (mm/min)** of the controller. **ae (mm)** and **ap (mm)** are saved with the controller.

| Quantity | Calculation |
|---|---|
| Effective diameter Deff | D. Ball end mill below ap = D/2: 2 sqrt(ap (D - ap)). V bit and chamfer: tip + 2 ap tan(angle / 2), at most D |
| Spindle speed n | Vc × 1000 / (π Deff), Vc from the material table (carbide or HSS column; dovetail × 0.8, drill × 0.7), limited to **Spindle min (rpm)** .. **Spindle max (rpm)** |
| Chip load fz | fz10 × (D / 10)^0.8 from the material table, × 0.8 ball end mill, × 0.6 V bit and chamfer, × 0.5 dovetail, × 0.8 HSS |
| Radial chip thinning | fz × 1 / sqrt(1 - (1 - 2 ae / Deff)^2) for ae below Deff / 2, at most × 3 |
| Feed | fz (thinned) × flutes × n, at most **Max feed (mm/min)**. Drill: feed per revolution fdrill × D × n |
| Plunge feed | Feed × the plunge fraction of the material (0.25 to 0.6). Drill: the feed |
| Mean chip thickness hm | fz (thinned) × sqrt(ae / Deff). Drill: fz sin(point angle / 2) |
| Removal rate | ae × ap × feed / 1000 cm^3/min. Drill: π D^2 / 4 × feed |
| Power | removal rate × kc / 60000 / 0.8 kW, kc = kc1.1 × hm^-mc |
| Available power | **Spindle power (kW)** × n / **Rated speed (rpm)** below the rated speed, else **Spindle power (kW)**. Above it the feed is lowered until the power fits |

Messages: the spindle speed raised to **Spindle min (rpm)**, the feed limited by the spindle power, a mean chip thickness below 0.008 mm in metals (the edge rubs). **Limited by** names **Spindle max (rpm)**, **Max feed (mm/min)** or the spindle power.

| Group | Materials |
|---|---|
| Aluminium | Aluminium wrought (6061, 6082), Aluminium 7075, Aluminium cast (AlSi) |
| Steel | Free-cutting steel (11SMnPb30), Structural steel (S235, S355), Alloy steel annealed (42CrMo4), Tool steel annealed (1.2842, 1.2379), Stainless steel (304, 316) |
| Brass and bronze | Brass (CuZn39Pb3), Bronze (CuSn8, CuSn12) |
| Plastics | POM (acetal), PA (nylon), PE, UHMW-PE, PMMA (acrylic), PVC |
| Wood and boards | Hardwood (oak, beech), Softwood (pine, spruce), MDF, Plywood (birch) |

The table values are in `drawgen/cam/feeds.py` (`MATERIALS`: Vc carbide and HSS m/min, fz10 mm/tooth, kc1.1 N/mm^2, mc, plunge fraction, fdrill mm/rev per mm). They are starting values for a rigid set-up (a router frame and spindle usually need lower values).

## 16.3 Operations

The command window of an operation opens when the operation is added, on a double click of its row, or with **Edit** in its properties. It has the name of the operation and the sections below; the active section is framed. **OK** closes the window. **Cancel** restores the operation to its state when the window opened; a new operation is removed. Every change in the window reruns the operations up to the edited one and shows the toolpaths (the edited operation in colour, the earlier ones grey), the stock and the messages (preview). The G-code of the edited operation is shown with **Inspect G-code**.

| Section | Content |
|---|---|
| **Base geometry** | The faces, edges or points the operation works on. **Faces**, **Edges** or **Points** chooses what a click in the view picks when the operation takes several kinds; the faces the operation can take are tinted blue; a click adds a face or an edge, a second click removes it; the picks are listed as chips (**×** removes one, **Clear** all; the chip under the mouse is highlighted in the view). Engrave and Vcarve also take a saved **Sketch** of the project (Sketch tab, XY plane) and a **Text** (**Text**, **Size (mm)** the cap height, **Font** file name, **X (mm)**, **Y (mm)** of the base line start, **Angle (deg)**, **Align**) |
| **Depths** | **Start depth (mm)**, **Final depth (mm)**, **Step down (mm)**, **Finish depth (mm)** in job coordinates. An empty field takes the default: the start depth is the top of the stock over the geometry (a pocket: the stock over the floor; an engraving: the part surface under the path), the final depth comes from the geometry (the floor, the hole bottom, the part bottom), step down and finish depth from the setup sheet. The resolved values are shown greyed after a preview |
| **Heights** | **Clearance height (mm)** for the rapid moves between operations and **Safe height (mm)** for the rapid moves inside the operation; empty: the start depth plus the setup sheet offsets |
| **Operation** | **Tool controller**, the fields of the type (below), **Feed (mm/min)**, **Plunge (mm/min)**, **Spindle (rpm)** (empty: the controller values), **Calculate** (the three fields from the feeds and speeds calculator: ae the step over of Adaptive, Face, Helix, 3D Pocket, 3D Surface and Waterline, the step of the Undercut passes, else D; ap the step down of the operation, the depth of Engrave, the width plus extra depth of Deburr, the flank height of a dovetail; the line below gives ae, ap, the chip load, the power and the limits), **Comment** (written in the G-code before the operation) |

The levels of an operation: the first level is one step down below the start depth, the last level is the final depth; with a finish depth above 0 the level before the last is at final depth + finish depth. The depth of a level is at most the cutting height of the tool. The paths are polylines (G01) and arcs (G02, G03); offset paths round the corners with 12 segments per quarter circle and keep the chords clear of the walls by the chord sag. **Step over (% of D)** is the distance between passes as a percentage of the tool diameter.

### Profile

The contour of the part, of the picked faces or of the picked edges, cut in levels.

| Field | Function |
|---|---|
| **Base geometry** | Faces or edges of the contour. None: the outline of the part section just above the bottom |
| **Side** | **Outside** or **Inside** of the contour |
| **Direction** | **Climb (CW)** or **Conventional (CCW)** |
| **Extra offset (mm)** | Material left on the contour |
| **Passes** | Passes stepping out from the contour by the step over |
| **Below the bottom (mm)** | The lowest level below the bottom of the contour |
| **Process perimeter**, **Process holes**, **Process circles** | The outer contour, the inner contours and the circular holes of the picked faces |

Each level is entered with a plunge at the contour start (a Ramp entry dressup replaces the plunges).

### Pocket Shape

The material above the picked floor faces cleared in levels. A floor face is a horizontal face of the part with the material above it: the floor of a pocket, or the top of a step beside a boss or a rail. Picked wall faces that enclose a region are cleared as the region.

| Field | Function |
|---|---|
| **Pattern** | **Offset** (loops from the inside out), **ZigZag**, **ZigZag then offset** (ZigZag passes and a loop along the boundary), **Line**, **Spiral** |
| **Step over (% of D)**, **Angle (deg)** | Distance and direction of the passes |
| **Cut mode** | **Climb (CW)** or **Conventional (CCW)** |
| **Start at** | **Centre** (the loops from the innermost outward) or **Boundary** |
| **Extra offset (mm)** | Material left on the walls by the pattern |
| **Finish pass** | A pass along the walls at extra offset 0 on every level (with an extra offset above 0) |
| **Entry** | **Helix**: arcs down to the level about a point with the tool inside the region, quarter turns, a flat turn at the level, then a move to the first pass. **Plunge**: straight down at the first pass |
| **Helix pitch (mm)** | Depth per turn of the helix. The helix radius is 0.5 x R, 0.35 x R or 0.25 x R, the largest with room in the region; without room the level starts with a plunge (message) |
| **Keep tool down** | A link between passes is a feed move at the level when its line lies in the region; else the tool lifts to the safe height and plunges again (message with the count) |
| **Use outline** | Islands ignored: the outline of the floor |

Region of a level: the floor polygon, with the holes that go down (a pocket or a hole in the floor) filled in and the islands (faces rising from the floor) kept; an edge of the outer boundary whose other face does not rise above the floor is open, and the region extends beyond it by 2 x R + extra offset + 1 mm; the section of the part between the level and the reach of the tool above it (the cutting height), offset by the extra offset, is taken away (walls, islands and overhangs); the result is offset inward by the tool radius. The levels start at the top of the stock over the floor polygon. After the levels the material left above the floor within the floor polygon is reported.

### Drilling

| Field | Function |
|---|---|
| **Base geometry** | Cylindrical faces with a vertical axis; one hole per axis position |
| **Peck depth (mm)** | Depth per peck: after each peck the tool retracts to the retract height and comes back to 0.5 mm above the depth reached. 0: one plunge |
| **Dwell (s)** | At the bottom of the hole (`G4` of the generic post; a comment in the Estlcam post) |
| **Retract height (mm)** | Above the start depth between pecks |
| **Depth** | **From the hole** (through when the hole reaches the part bottom, else to the hole bottom), **Through**, **Hole bottom** |
| **Breakthrough (mm)** | Below the part bottom of a through hole |
| **Add the drill tip** | The tip length (from the point angle) added to the depth |

The start depth is the top of the hole when the stock above it is cleared. A hole whose diameter differs from the tool diameter by more than 0.05 mm is drilled with a message.

### Face

| Field | Function |
|---|---|
| **Boundary** | **Stock** (the stock bounding box in X and Y), **Part bounding box**, **Picked faces** |
| **Pattern** | **ZigZag**, **Line** (passes in one direction with a lift between them), **Offset**, **Spiral** |
| **Step over (% of D)**, **Angle (deg)** | Distance and direction of the passes |
| **Overhang (mm)** | Tool centre beyond the boundary at the pass ends, in addition to the tool radius |
| **Cut mode** | **Climb (CW)** or **Conventional (CCW)** |

The default depths are the stock top and the part top.

### Helix

The picked holes cleared with helical passes of an end mill smaller than the hole.

| Field | Function |
|---|---|
| **Direction** | **Climb (CW)** or **Conventional (CCW)** |
| **Start side** | **Outside** (the pass along the wall first, stepping in) or **Inside** |
| **Step over (% of D)** | Distance between the passes |
| **Extra offset (mm)** | Material left on the wall |
| **Breakthrough (mm)** | Below the part bottom of a through hole |

The pitch of the helix is the step down.

### Adaptive

Clearing or profiling with continuous spiral paths of the tool centre whose radial engagement stays at the step over: the loops of the region offset inward by multiples of the step over, from the innermost outward, each loop morphed into the next.

| Field | Function |
|---|---|
| **Base geometry** | Floor faces. None: the stock over the part |
| **Mode** | **Clearing** of the region or **Profiling** of a band of **Passes (profiling)** x step over around the walls |
| **Step over (% of D)** | Radial engagement |
| **Tolerance (mm)** | Path simplification |
| **Helix ramp angle (deg)**, **Helix diameter (mm)** | The helix entry (diameter 0: half the tool diameter) |
| **Lift (mm)** | Lift above the level between separate regions |
| **Stock to leave (mm)** | Material left on the walls |
| **Finish profile** | A pass along the walls at the end of every level |
| **Use outline** | Islands ignored |

### Slot

A straight or circular slot along its centre line.

| Field | Function |
|---|---|
| **Base geometry** | Two points (**Points**: a click on the model gives a point; **P1 X**, **P1 Y**, **P2 X**, **P2 Y** in mm), an edge (a line, or an arc or a circle for a circular slot) or the slot floor (a face with two rounded ends: the centre line between the ends) |
| **Extend start (mm)**, **Extend end (mm)** | The centre line extended |
| **Radius offset (mm)** | Of a circular slot from an arc edge |
| **Layer mode** | **Multi pass** (levels) or **Single pass** at the final depth |
| **Reverse direction** | |

The default start depth is the part surface under the slot; the default final depth is the bottom of the edge or of the floor, else the part bottom.

### Engrave

Picked edges, the curves of a saved sketch or the outlines of a text followed at the levels from the start depth to the final depth.

| Field | Function |
|---|---|
| **Base geometry** | Edges; **Sketch**; **Text** |
| **Depth (mm)** | Below the surface (when the final depth is empty) |
| **Start vertex** | Start of a closed path |

The default start depth is the part surface under the paths. The volume cut from the part is reported as cut from the part (an engraving cuts the part by design and is not a gouge).

### Deburr

A chamfer along the picked edges (or the outer edges of the picked faces) with a V bit or a chamfer bit.

| Field | Function |
|---|---|
| **Width (mm)** | Width of the chamfer |
| **Extra depth (mm)** | The tip below the chamfer |
| **Direction** | **Climb (CW)** or **Conventional (CCW)** |
| **Entry point** | Start vertex of a closed path |

### Vcarve

Closed regions carved along their centre lines with a V bit: the depth at a point of the centre line is the depth at which the bit touches both sides of the region. Parts of a region wider than the bit at the final depth are cleared at the final depth.

| Field | Function |
|---|---|
| **Base geometry** | Faces (their outlines are the regions), a **Sketch** with closed loops, a **Text** |
| **Discretize (mm)** | Step along the outline for the centre lines |
| **Threshold** | Centre lines of the inner corners dropped below this value (0 to 0.9) |
| **Colinear filter (mm)** | Collinear points of the centre lines removed |

The moves vary in Z continuously. The stock is simulated on a height map; the solid stock is cut by the envelope of the regions ([section 16.7](#167-simulation-sanity-check-and-results)).

### Undercut

The material under an inclined face removed with a dovetail cutter. The faces are straight, open at both ends and cleared by an earlier operation (a pocket on the floor beside the rail) to their base Z.

| Field | Function |
|---|---|
| **Base geometry** | Undercut faces: planar faces whose outward normal points downward and sideways |
| **Step over (mm)** | Step of the roughing passes into the undercut |
| **Allowance (mm)** | Material left on the face by the roughing passes and removed by the finish pass. 0: the last roughing step is the finish pass |
| **Run-out (mm)** | Distance of the cutter edge beyond the face ends at the start and the end of a pass |
| **Reverse** | Passes in the other direction along the face |

Geometry read from each face: the angle to the base plane, the height, the undercut depth (height / tan(angle)), the base Z, the bottom edge and its direction, the length and the horizontal direction out of the material. Passes of each face, all at the base Z: the cutter axis is at D/2 outside the bottom edge for the finish pass; the roughing passes start at the undercut depth minus the step over outside that position and step in by the step over until the allowance is reached, then a pass at the allowance and the finish pass. Each pass: rapid to the clearance height above the start point, which is D/2 plus the run-out beyond the face end; plunge to the base Z; feed along the face to D/2 plus the run-out beyond the other end; rapid up.

Checks before any cut of a face (the operation is refused with the message): the tool is a dovetail cutter; the cutter angle is within 0.5 deg of the face angle; the cutting height is at least the undercut height; the cutter radius is more than the undercut depth. Checks of each pass against the stock as cut by the earlier passes and operations: the whole tool plunged to the pass start and lifted from the pass end is outside the stock (the end of the undercut is not open or the stock is not cleared); the neck and the shank swept along the pass are outside the stock. The swept cutting part is subtracted from the stock exactly.

## 16.4 3D operations

The 3D operations work on a height map of the part: the highest Z of the part at every point of a grid with the **Sample interval (mm)** as the step, from the tessellation of the solid. The height of the tool centre at every grid point comes from the surface dilated by the tool profile (ball, bull nose and flat end mills), with one grid cell of margin. An undercut is not represented (one Z per point).

| Field (all three) | Function |
|---|---|
| **Boundary** | **Stock** (the stock area), **Picked faces** (the area of the faces), Face: **Bounding box** of the faces |
| **Boundary adjust (mm)** | The boundary offset; positive outward |
| **Sample interval (mm)** | Grid of the height map and step along the lines |
| **Depth offset (mm)** | Left on the surface |
| **Optimize** | Collinear points removed |

### 3D Pocket

The volume above the picked faces cleared in levels; at every level the region is where the tool centre may stand over the surface, cleared with **Pattern**, **Step over (% of D)**, **Angle (deg)**, **Cut mode**, **Entry** and **Helix pitch (mm)** as a Pocket Shape.

### 3D Surface

The tool follows the surface along a pattern: **Line**, **ZigZag**, **Circular**, **Circular ZigZag**, **Offset**, **Spiral** with **Step over (% of D)** and **Angle (deg)**; **Layer mode** **Single pass** on the surface or **Multi pass** (levels clipped at the surface); **Boundary enforcement** keeps the tool inside the boundary. A change of Z larger than two sample intervals between consecutive points is taken as a step: the tool moves at the higher Z over the lower point before descending.

### Waterline

At every level from the start depth to the final depth the contours where the tool touches the surface, inside the boundary; **Cut mode**; **Clear last level** clears the last level as a pocket.

## 16.5 Dressups

A dressup changes the moves of its operation. The dressups of an operation are applied in the order Dogbone, Tag, Lead in/out, Ramp entry, Boundary. A dressup is added to the selected operation (or to the operation open in the command window) from **Dressup ▾**; its command window has the fields below; its row in the tree is under the operation.

| Dressup | Fields |
|---|---|
| **Tag** | Holding tags on the lowest closed loop of the operation: **Tags** spaced along the loop, **Width (mm)** between the tool edges, **Height (mm)**, **Angle (deg)** of the flanks (90: vertical). The tool rises over a tag and comes down behind it |
| **Ramp entry** | The plunges to a level replaced by ramps along the path at **Angle (deg)**: **RampMethod1** (ramp down along the path, back to the start at the level, then the path), **RampMethod2** (ramp down, then the path on from there), **ZigZag** (back and forth over the ramp length), **Helix** (a helix at the start point). **Ramp from the start depth**; **Ramp feed (mm/min)** (empty: the plunge feed) |
| **Lead in/out** | **Style** **Arc**, **Tangent** or **Perpendicular**, **Length (mm)** (the arc radius or the line length), **Lead in**, **Lead out**, **Extend (mm)** along the path |
| **Dogbone** | Inside corners of the path cut out so that a square part fits: **Style** **Dogbone** (along the bisector), **T-bone horizontal**, **T-bone vertical**, **T-bone long edge**, **T-bone short edge**; **Side** of the material (**Left**, **Right**); **Incision** **Adaptive** (to the corner), **Fixed** (the tool radius), **Custom** (**Length (mm)**) |
| **Boundary** | The path cut at the rectangle **X min (mm)**, **X max (mm)**, **Y min (mm)**, **Y max (mm)**; **Keep inside** keeps the part of the path inside the rectangle (else outside); the tool lifts at the cuts |

## 16.6 Supplemental, Copy and Array

| Operation | Fields and G-code |
|---|---|
| **Fixture** | **Work offset** `G54` to `G59`; **Shift X (mm)**, **Shift Y (mm)**, **Shift Z (mm)**. The generic post writes the G-code; the Estlcam controller has no coordinate systems, so the Estlcam post shifts the coordinates of the following moves by the shift and writes a comment |
| **Comment** | **Text**, written as a comment in parentheses (parentheses in the text become brackets) |
| **Stop** | `M00`, or `M01` with **Optional stop (M01)**; the spindle is stopped before `M00` |
| **Custom** | **G-code** lines written as they are |
| **Copy** | The moves of **Operation** (an earlier cutting operation) again, with its tool controller |
| **Array** | The moves of **Operation** repeated: **Type** **Linear** with **Copies** (including the base position), **Offset X (mm)**, **Offset Y (mm)**; **Polar** with **Copies** over **Angle (deg)** about **Centre X (mm)**, **Centre Y (mm)**. The base operation stays in the job; it is set inactive when its position is in the array |

## 16.7 Simulation, sanity check and results

**Simulate** computes the operations in the list order. The stock of an operation is the stock left by the earlier operations. An operation that fails leaves the stock unchanged; the later operations run on that stock. The preview of the command window runs the operations up to the edited one; the results of the earlier operations are kept on the server, so a change of one operation recomputes that operation and the later ones.

The stock is cut as follows. The moves are grouped by Z level (a sloping move in pieces of 1 mm assigned to the nearest level at or below). At each level the path of the tool centre is swept by the cutting profile of the tool as a stack of slabs (a flat end mill: a cylinder of the tool radius; a ball end mill, a V bit or a drill: steps of the profile of at most 0.3 mm or D/8 radius change, each step with its larger radius) from the level up to the cutting height, and subtracted from the stock; the neck and the shank over the path are checked against the stock before the level is cut (the message "the neck or shank of the tool collides with the stock" refuses the operation). The part material cut by an operation (its gouge) is the part inside the stock before the operation less the part inside the stock after it; a gouge above 0.05 mm^3 is reported and marked ⚠ in the tree. An engraving operation (Engrave, Deburr, Vcarve) cuts the part by design: its volume is reported as cut from the part.

The Undercut operation cuts the stock with the exact swept solids of the dovetail cutter. The 3D operations and Vcarve are also simulated on a height map of the stock with the tool profile (removed volume, gouge and the material left over the part within the boundary, on the grid of the sample interval). Vcarve cuts the solid stock by the envelope of its regions (vertical walls); 3D Surface leaves the solid stock unchanged and shows the cut surface from the height map in the view (**3D surfaces**); Waterline and 3D Pocket cut the solid stock by their levels.

The properties of an operation after a run: ok or error with the messages; the resolved heights (clearance, safe, start, final, step); the removed volume, the material left (pockets), the gouge, the cut and rapid lengths, the cycle time (feeds and the rapid speeds of the setup sheet), the feeds, the spindle speed and the number of moves; a table of the levels with **Z (mm)**, **Length (mm)** of the cut moves and **Removed (mm^3)**. The status line after **Simulate** gives the number of operations, the cycle time, the volume of the stock outside the part (films thinner than 0.02 mm left out) and the volume of the part cut away.

**Sanity check** lists errors, warnings and information in the properties panel: no part chosen, no tool controller, a controller whose bit is not in the library or whose feeds are 0, two controllers with one tool number, an operation without a controller or without base geometry, a final depth not below the start depth, a controller spindle speed outside **Spindle min (rpm)** to **Spindle max (rpm)**, a controller feed above **Max feed (mm/min)**, a copy of an operation that is not in the job, a stock that does not cover the part, an empty output file name, and after a run the errors and gouges of the operations. **Simulate** shows the sanity check when it has errors or warnings.

## 16.8 Post process

**Post process** runs the operations and writes the G-code file to the **G-code folder** (empty: `cam/` of the project; no project open: download) under the **File name** of the output (empty: `<job>.nc`). A file of that name is overwritten after a question. **Download G-code** sends the file to the browser. An operation with an error gives no file. **Inspect G-code** shows the G-code of the selected operation (no selection: the whole job) in a window in the view.

Both post-processors write mm, absolute machine coordinates with three decimals and a decimal point, parentheses comments, a comment with the machine zero in job coordinates, per cutting operation a comment with the type, the name and the tool controller, a tool change when the tool number changes, the moves as rapid `X Y Z`, feed `X Y Z F<feed>` and arcs `X Y Z I J F<feed>` (I and J from the start point of the arc, Z along the arc for a helix); the feed word is written when the feed changes.

| Post-processor | File |
|---|---|
| **Estlcam controller** (default) | The commands of the Estlcam controller (https://www.estlcam.de/steuerung_cnc_programme.php): `G00`, `G01`, `G02`, `G03` with the G-code on every move line, one G-code and one M-code per line; `M06 T<n>` at a tool change (the controller stops for the manual tool change; the tool setter routine runs from the controller), `S<rpm>`, `M03`, `G00 Z<clearance>`, the moves, `M05` before a tool change and at the end; `M00` and `M01` for a Stop; a dwell and a fixture as comments (the fixture shift applied to the coordinates); at the end `G00 Z<clearance>` and the comment `(end)`. No unit, plane, coordinate system or program end commands |
| **Generic (G21 G90 G54, M30)** | `%`, `G21 G90 G17 G40 G49 G54`, `G94`; `T<n> M6`, `S<rpm> M3` (`M4` for a CCW controller), `G0 Z<clearance>`, the moves as `G0`, `G1`, `G2` and `G3`, `G4 P<s>` for a dwell, `G54` to `G59` for a fixture, `M0` and `M1` for a Stop, `M5`; at the end `G0 Z<clearance>`, `M30`, `%` |

## 16.9 Job template

**Export template** downloads the job as `<job>.camtemplate.json`: the setup sheet, the tool controllers, the post-processor, the stock, the machine zero and the operations without their base geometry. **Import template…** applies a template file to the open job: its setup sheet, controllers, post-processor, stock, machine zero and operations replace those of the job (the base geometry of the operations is empty afterwards, the operations get new ids).

## 16.10 Files

| File | Content |
|---|---|
| `work/<name>.cam.json` | The job: `name`, `source` (the part), `stock`, `origin`, `setup`, `tools` (the controllers), `post`, `output`, `operations` (id, name, type, active, tc, comment, the heights and depths, dressups, the fields of the type, faces as face keys and edges as edge keys of the part, points, sketch name, text), `next` |
| `<name>.sccam` | Document file of the job ([section 2.2](02-files.md#22-document-files)); the part is in `uses/` |
| `cam/<name>.nc` | The G-code file |
| `config.json` `cam_tools` | The tool bit library |

A job saved by an earlier version (stock as `top`, `sides`, `bottom`; `clearance`; operations with `tool` and `suppressed`; `drill`; profile `tabs` and `ramp_angle`) is read in the current form: offsets, a setup sheet, tool controllers made from the tool ids, `drilling`, Tag and Ramp entry dressups.

The faces of an operation are stored as face keys (centre, normal, area) and the edges as edge keys (midpoint, length) of the part. A face or an edge is found again after a rebuild of the part by its key (within 0.05 mm); one that is not found is left out, and an operation without geometry reports it.

## 16.11 FreeCAD CAM workbench correspondence

| FreeCAD | ShinyCAD CAM |
|---|---|
| Job (Model, Stock, SetupSheet, Tools, Operations, Output) | The job tree ([section 16.1](#161-job-tree)) |
| ToolBit library, ToolController | Tool bits ([section 16.2](#162-tool-bits-and-tool-controllers)), tool controllers |
| Profile, Pocket Shape, Drilling, Face, Helix, Adaptive, Slot, Engrave, Deburr, Vcarve | The operations of [section 16.3](#163-operations) |
| 3D Pocket, 3D Surface, Waterline | [Section 16.4](#164-3d-operations) |
| Tag, RampEntry, LeadInOut, Dogbone, Boundary dressups | [Section 16.5](#165-dressups) |
| Fixture, Comment, Stop, Custom, Copy, Array | [Section 16.6](#166-supplemental-copy-and-array) |
| Simulator, Sanity check, Inspect G-code, Post process, Export template | [Sections 16.7](#167-simulation-sanity-check-and-results) to [16.9](#169-job-template) |
| Probe, Hop, Axis map, Pocket (legacy), Shape (legacy), Thread milling | Not available |
| Undercut | Added: the dovetail cutter operation |

[Contents](../README.md) · [← 15. Limitations](15-limitations.md)
