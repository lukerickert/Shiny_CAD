# -*- coding: utf-8 -*-
"""Model placement of a CAM job: the part moved and turned in the job coordinate system before the stock, the
machine zero and the operations are worked out (the job coordinate system is the coordinate system of the
toolpaths; its XY plane is the machine table plane, +Z the spindle axis).

Placement record (doc["placement"]):
  {"pos": [x, y, z] mm, "rot": [rx, ry, rz] deg (rotations about the fixed X, then Y, then Z axis about the part
   origin, then the translation: the convention of assembly components),
   "constraints": [{"id", "type": "coincident" | "distance" | "parallel" | "angle" | "concentric",
       "face": index of the face of the part (shape.faces() order), "fc": centre of that face in part coordinates
       (filled by solve; used to find the face again when the part changes), "datum": "XY" | "XZ" | "YZ" | "X" |
       "Y" | "Z", "value": mm (distance) or deg (angle), "flip": false, "suppressed": false}],
   "next": n}

The constraints are assembly mates (assembly.py) between a face of the part and a datum plane or axis of the job
coordinate system: the datums form a fixed component, the part the free one."""
import hashlib
import json
import math

DATUMS = {
    "XY": {"kind": "plane", "c": [0.0, 0.0, 0.0], "n": [0.0, 0.0, 1.0]},
    "XZ": {"kind": "plane", "c": [0.0, 0.0, 0.0], "n": [0.0, 1.0, 0.0]},
    "YZ": {"kind": "plane", "c": [0.0, 0.0, 0.0], "n": [1.0, 0.0, 0.0]},
    "X": {"kind": "axis", "c": [0.0, 0.0, 0.0], "p": [0.0, 0.0, 0.0], "n": [1.0, 0.0, 0.0]},
    "Y": {"kind": "axis", "c": [0.0, 0.0, 0.0], "p": [0.0, 0.0, 0.0], "n": [0.0, 1.0, 0.0]},
    "Z": {"kind": "axis", "c": [0.0, 0.0, 0.0], "p": [0.0, 0.0, 0.0], "n": [0.0, 0.0, 1.0]},
}
TYPES = ("coincident", "distance", "parallel", "angle", "concentric")
TYPE_NAMES = {"coincident": "Coincident", "distance": "Distance", "parallel": "Parallel", "angle": "Angle",
              "concentric": "Concentric"}


def _f(v, default=0.0):
    try:
        return float(default) if v is None or v == "" else float(v)
    except (TypeError, ValueError):
        return float(default)


def normalize(pl):
    """The placement record with every field present."""
    pl = dict(pl or {})
    pl["pos"] = [_f(v) for v in (list(pl.get("pos") or []) + [0, 0, 0])[:3]]
    pl["rot"] = [_f(v) for v in (list(pl.get("rot") or []) + [0, 0, 0])[:3]]
    pl["constraints"] = [dict(c) for c in pl.get("constraints") or [] if isinstance(c, dict)]
    pl.setdefault("next", len(pl["constraints"]) + 1)
    return pl


def is_identity(pl):
    pl = normalize(pl)
    return all(abs(v) < 1e-12 for v in pl["pos"] + pl["rot"])


def key(pl):
    """Text of the transform for the cache key of the placed shape ("" without a transform)."""
    pl = normalize(pl)
    if is_identity(pl):
        return ""
    return hashlib.sha1(json.dumps([round(v, 9) for v in pl["pos"] + pl["rot"]]).encode("utf-8")).hexdigest()[:16]


def apply(shape, pl):
    """The shape moved by the placement (the same shape without a transform)."""
    pl = normalize(pl)
    if is_identity(pl):
        return shape
    from .. import assembly
    return assembly.place(shape, {"pos": pl["pos"], "rot": pl["rot"]})


def face_refs(shape):
    """Face references of the unplaced part (assembly.face_refs: kind plane | cylinder | other, c, n, p, r)."""
    from .. import assembly
    return assembly.face_refs(shape)


def _face_of(c, refs):
    """Index of the face of a constraint: the face whose centre is at "fc" (within 0.05 mm), else "face"."""
    fc = c.get("fc")
    if fc and len(fc) == 3:
        best, bd = None, 0.05
        for i, r in enumerate(refs):
            if r:
                d = math.dist(r["c"], fc)
                if d < bd:
                    best, bd = i, d
        if best is not None:
            return best
    i = c.get("face")
    try:
        i = int(i)
    except (TypeError, ValueError):
        return None
    return i if 0 <= i < len(refs) and refs[i] else None


def solve(pl, shape):
    """Solve of the constraints from the current placement: {"pos", "rot", "constraints" (fc filled), "messages",
    "unsatisfied": {constraint id: text}, "flipped": [ids]}. A constraint whose face is lost is reported and left out."""
    from .. import assembly
    pl = normalize(pl)
    refs = face_refs(shape)
    msgs, mates, lost = [], [], {}
    for c in pl["constraints"]:
        name = TYPE_NAMES.get(c.get("type"), c.get("type") or "?")
        if c.get("suppressed"):
            continue
        if c.get("type") not in TYPES:
            lost[c.get("id")] = "unknown type %s" % c.get("type")
            continue
        if c.get("datum") not in DATUMS:
            lost[c.get("id")] = "no datum plane or axis"
            continue
        i = _face_of(c, refs)
        if i is None:
            lost[c.get("id")] = "the face is not found in the part"
            continue
        r = refs[i]
        if r["kind"] not in ("plane", "cylinder"):
            lost[c.get("id")] = "the face is neither planar nor cylindrical"
            continue
        c["face"] = i
        c["fc"] = r["c"]
        mates.append({"id": c.get("id"), "name": name, "type": c["type"], "value": _f(c.get("value")),
                      "flip": bool(c.get("flip")), "a": {"comp": "part", "face": i}, "b": {"comp": "datum", "datum": c["datum"]}})
    for cid, t in lost.items():
        msgs.append("constraint %s left out: %s" % (cid, t))
    out = {"pos": pl["pos"], "rot": pl["rot"], "constraints": pl["constraints"], "messages": msgs,
           "unsatisfied": dict(lost), "flipped": []}
    if not mates:
        return out
    asm = {"components": [{"id": "datum", "name": "Datum", "fixed": True, "pos": [0, 0, 0], "rot": [0, 0, 0]},
                          {"id": "part", "name": "Part", "pos": pl["pos"], "rot": pl["rot"]}],
           "mates": mates}
    detail = {}
    res, _nr, ms = assembly.solve_mates(asm, lambda cid: refs if cid == "part" else [],
                                        lambda cid: DATUMS if cid == "datum" else {}, detail)
    if "part" in res:
        pos, rot = res["part"]
        out["pos"] = [round(v, 4) + 0.0 for v in pos]
        out["rot"] = [round(v, 5) + 0.0 for v in rot]
    out["messages"] += [m.replace("Part / Datum ", "") for m in ms]
    out["unsatisfied"].update({k: v.replace("Part / Datum ", "") for k, v in (detail.get("unsatisfied") or {}).items()})
    out["flipped"] = list(detail.get("flipped") or [])
    for c in pl["constraints"]:
        if c.get("id") in out["flipped"]:
            c["flip"] = not c.get("flip")
    return out


def suggest(pl, shape, face, ctype):
    """Datum and Flip of a new constraint on a face that keep the part where it is as far as possible: the datum plane
    (or axis for a cylinder) closest in direction to the placed face normal (axis), Flip when the normals point the
    same way."""
    from .. import assembly
    pl = normalize(pl)
    refs = face_refs(shape)
    if not (0 <= int(face) < len(refs)) or not refs[int(face)]:
        raise ValueError("no such face")
    r = refs[int(face)]
    if r["kind"] not in ("plane", "cylinder"):
        raise ValueError("pick a planar or a cylindrical face")
    R = assembly._rot_matrix(pl["rot"])
    n = assembly._apply(R, [0, 0, 0], r["n"], point=False)
    axis_like = r["kind"] == "cylinder" or ctype == "concentric"
    names = ("X", "Y", "Z") if axis_like else ("YZ", "XZ", "XY")
    k = max(range(3), key=lambda i: abs(n[i]))
    datum = names[k]
    flip = n[k] > 0                     # facing by default: Flip keeps a face whose normal points along the datum normal
    value = 0.0
    if ctype == "distance" and not axis_like:
        c = assembly._apply(R, pl["pos"], r["c"])
        value = round(-c[k] * (1.0 if n[k] > 0 else -1.0), 6)
    return {"datum": datum, "flip": bool(flip), "value": value, "kind": r["kind"]}
