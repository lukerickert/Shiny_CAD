// CAM tab: a job on a saved part for a 3-axis machine in the manner of the FreeCAD CAM workbench: job tree
// (operations with their dressups, model with its placement, stock, setup sheet, tool controllers), a command window in
// the view for the operation being edited (base geometry picked in the view, depths, heights, fields of the
// type) with a live preview of the toolpaths, the stock cut by the tool on the server, the tool bit library,
// sanity check, G-code inspection and the post-processed file.
import * as THREE from "three";
import { TumbleControls } from "/static/vendor/TumbleControls.js";
import { updateAxes } from "/static/axes.js";
import { createNavCube } from "/static/navcube.js";

const CM = { doc: null, dirty: false, three: null, geo: null, bbox: null, size: 100,
             sel: null,          // selected tree item: "job" | "ops" | "model" | "part" | "pc:<id>" | "stock" | "setup" | "tools" | "tc:<id>" | op id | "dr:<op id>:<i>"
             cmd: null,          // {id, dr, step, snapshot} while an operation (or its dressup dr) is edited in the command window
             res: null,          // result of the last run or preview
             resUpto: null,      // index of the last operation of a preview run (null: the whole job)
             setup: null,        // {stock_bbox, part_bbox, origin, clearance_z}
             hidden: {},         // tree items whose geometry is hidden (eye)
             fold: { tools: true },   // folded tree items
             placeRes: null,     // result of the last placement solve {messages, unsatisfied}
             bits: [], posts: [], meta: null, sketches: [], seq: 0, previewTimer: null, previewSeq: 0, chipHover: null, cmdPos: null };
const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const fmt = (v, d = 4) => {
  if (v === null || v === undefined || !isFinite(v)) return "-";
  let s = Number(v).toPrecision(Math.max(d, 1));
  if (s.includes(".") && !s.includes("e")) s = s.replace(/\.?0+$/, "");
  return s === "-0" ? "0" : s;
};
const num = v => { const x = window.numv(String(v)); return isFinite(x) ? x : NaN; };
const COLORS = { part: 0x9aa7b5, under: 0x74c0fc, sel: 0xf08c00, pickable: 0xa5d8ff, stock: 0x4c6ef5, left: 0xe03131, hm: 0x8ce99a,
                 rapid: 0xe8590c, plunge: 0x1c7ed6, feed: 0x2b8a3e, arc: 0x7048e8, dim: 0xadb5bd, edgeSel: 0xf08c00 };
/** Points along an arc from a to b about c (XY), Z interpolated, 24 segments per turn. */
function arcPoints(a, b, c, cw) {
  const ax = a[0] - c[0], ay = a[1] - c[1], bx = b[0] - c[0], by = b[1] - c[1];
  const r = Math.hypot(ax, ay), t0 = Math.atan2(ay, ax);
  let d = Math.atan2(by, bx) - t0;
  if (cw) { while (d > -1e-9) d -= 2 * Math.PI; } else { while (d < 1e-9) d += 2 * Math.PI; }
  const n = Math.max(2, Math.ceil(Math.abs(d) / (2 * Math.PI) * 24)), out = [];
  for (let i = 1; i <= n; i++) { const t = t0 + d * i / n; out.push([c[0] + r * Math.cos(t), c[1] + r * Math.sin(t), a[2] + (b[2] - a[2]) * i / n]); }
  return out;
}

// ------------------------------------------------------------------ operation and dressup definitions

const num_ = (k, label, title, def) => ({ k, label, kind: "num", title, def });
const sel_ = (k, label, opts, title, def) => ({ k, label, kind: "sel", opts, title, def: def === undefined ? (opts.length ? opts[0][0] : "") : def });
const chk_ = (k, label, title, def) => ({ k, label, kind: "chk", title, def: !!def });
const txt_ = (k, label, title, def) => ({ k, label, kind: "txt", title, def: def || "" });
const area_ = (k, label, title, def) => ({ k, label, kind: "area", title, def: def || "" });
const CW = [["CW", "Climb (CW)"], ["CCW", "Conventional (CCW)"]];
const PATTERNS = [["offset", "Offset"], ["zigzag", "ZigZag"], ["zigzag_offset", "ZigZag then offset"], ["line", "Line"], ["spiral", "Spiral"]];
const STEP = num_("stepover_pct", "Step over (% of D)", "Distance between the passes as a percentage of the tool diameter", 40);
const TEXT_FIELDS = [txt_("text", "Text", "Text to engrave; empty: none"), num_("size", "Size (mm)", "Height of the capital letters", 10), txt_("font", "Font", "Font file name (arial.ttf, DejaVuSans.ttf; empty: the default)"),
                     num_("x", "X (mm)", "Start of the base line in part coordinates", 0), num_("y", "Y (mm)", "", 0), num_("angle", "Angle (deg)", "Rotation of the text about its start", 0),
                     sel_("align", "Align", [["left", "Left"], ["centre", "Centre"], ["right", "Right"]])];
/** Operation types: label, tool shapes, base geometry (faces / edges / points with the face kinds taken), depths and
 *  heights sections, fields of the Operation section, sketch and text sources. */
const OPS = {
  profile: { label: "Profile", tools: ["endmill", "bullnose"], base: { faces: true, edges: true, hint: "Faces or edges of the contour (none: the outline of the part)" }, depths: true,
    fields: [sel_("side", "Side", [["outside", "Outside"], ["inside", "Inside"]]), sel_("direction", "Direction", CW), num_("extra_offset", "Extra offset (mm)", "Material left on the contour", 0),
             num_("passes", "Passes", "Passes stepping out from the contour", 1), num_("extra", "Below the bottom (mm)", "The lowest level below the bottom of the contour", 0.2),
             chk_("process_perimeter", "Process perimeter", "", true), chk_("process_holes", "Process holes", "The inner contours of picked faces"), chk_("process_circles", "Process circles", "Circular holes of picked faces")] },
  pocket: { label: "Pocket Shape", tools: ["endmill", "bullnose"], base: { faces: true, kinds: ["floor"], required: true, hint: "Floor faces: horizontal faces with the material above them" }, depths: true,
    fields: [sel_("pattern", "Pattern", PATTERNS), STEP, num_("angle", "Angle (deg)", "Direction of the ZigZag and Line passes", 0), sel_("cut_mode", "Cut mode", CW), sel_("start_at", "Start at", [["centre", "Centre"], ["boundary", "Boundary"]]),
             num_("extra_offset", "Extra offset (mm)", "Material left on the walls by the pattern", 0), chk_("finish", "Finish pass", "A pass along the walls on every level (with an extra offset above 0)", true),
             sel_("entry", "Entry", [["helix", "Helix"], ["plunge", "Plunge"]]), num_("helix_pitch", "Helix pitch (mm)", "Depth per turn", 1), chk_("keep_down", "Keep tool down", "Links inside the region at the level", true),
             chk_("use_outline", "Use outline", "Islands ignored: the outline of the floor")] },
  drilling: { label: "Drilling", tools: ["drill", "endmill"], base: { faces: true, kinds: ["hole"], required: true, hint: "Hole faces: cylindrical faces with a vertical axis" }, depths: true,
    fields: [num_("peck", "Peck depth (mm)", "0: one plunge", 0), num_("dwell", "Dwell (s)", "At the bottom of the hole", 0), num_("retract", "Retract height (mm)", "Above the start depth between pecks", 1),
             sel_("through", "Depth", [["auto", "From the hole"], ["through", "Through"], ["bottom", "Hole bottom"]], "From the hole: through when the hole reaches the part bottom", "auto"),
             num_("breakthrough", "Breakthrough (mm)", "Below the part bottom of a through hole", 1), chk_("tip", "Add the drill tip", "The tip length added to the depth", true)] },
  face: { label: "Face", tools: ["endmill", "bullnose"], base: { faces: true, hint: "Faces to face (with Boundary: faces); none: the stock top" }, depths: true,
    fields: [sel_("boundary", "Boundary", [["stock", "Stock"], ["boundbox", "Part bounding box"], ["faces", "Picked faces"]]), sel_("pattern", "Pattern", [["zigzag", "ZigZag"], ["line", "Line"], ["offset", "Offset"], ["spiral", "Spiral"]]),
             num_("stepover_pct", "Step over (% of D)", "", 60), num_("angle", "Angle (deg)", "Direction of the passes", 0), num_("overhang", "Overhang (mm)", "Tool centre beyond the boundary at the pass ends, in addition to the radius", 1), sel_("cut_mode", "Cut mode", CW)] },
  helix: { label: "Helix", tools: ["endmill", "bullnose"], base: { faces: true, kinds: ["hole"], required: true, hint: "Hole faces larger than the tool" }, depths: true,
    fields: [sel_("direction", "Direction", CW), sel_("start_side", "Start side", [["outside", "Outside"], ["inside", "Inside"]]), num_("stepover_pct", "Step over (% of D)", "", 50),
             num_("extra_offset", "Extra offset (mm)", "Material left on the wall", 0), num_("breakthrough", "Breakthrough (mm)", "Below the part bottom of a through hole", 1)] },
  adaptive: { label: "Adaptive", tools: ["endmill", "bullnose"], base: { faces: true, kinds: ["floor"], hint: "Floor faces (none: the stock over the part)" }, depths: true,
    fields: [sel_("mode", "Mode", [["clearing", "Clearing"], ["profiling", "Profiling"]]), num_("stepover_pct", "Step over (% of D)", "", 20), num_("tolerance", "Tolerance (mm)", "Path simplification", 0.02),
             num_("helix_angle", "Helix ramp angle (deg)", "", 3), num_("helix_diameter", "Helix diameter (mm)", "0: half the tool diameter", 0), num_("lift", "Lift (mm)", "Lift between separate regions", 1),
             num_("stock_to_leave", "Stock to leave (mm)", "", 0), chk_("finish_profile", "Finish profile", "A pass along the walls at the end of every level"), num_("passes", "Passes (profiling)", "", 2), chk_("use_outline", "Use outline", "Islands ignored")] },
  slot: { label: "Slot", tools: ["endmill", "bullnose", "ballend"], base: { faces: true, edges: true, points: 2, hint: "Two points (click the model), an edge (a line or an arc) or the slot floor" }, depths: true,
    fields: [num_("extend_start", "Extend start (mm)", "", 0), num_("extend_end", "Extend end (mm)", "", 0), num_("radius_offset", "Radius offset (mm)", "Of a circular slot from an arc edge", 0),
             sel_("layer", "Layer mode", [["multi", "Multi pass"], ["single", "Single pass"]]), chk_("reverse", "Reverse direction")] },
  engrave: { label: "Engrave", tools: ["vbit", "chamfer", "ballend", "endmill"], base: { edges: true, hint: "Edges to follow, or a saved sketch, or a text" }, depths: true, sketch: true, text: true,
    fields: [num_("depth", "Depth (mm)", "Below the surface (when the final depth is empty)", 0.3), num_("start_vertex", "Start vertex", "Start of a closed path", 0)] },
  deburr: { label: "Deburr", tools: ["vbit", "chamfer"], base: { edges: true, faces: true, required: true, hint: "Edges (or the outer edges of faces) to chamfer" }, depths: false,
    fields: [num_("width", "Width (mm)", "Width of the chamfer", 1), num_("extra_depth", "Extra depth (mm)", "Tip below the chamfer", 0.5), sel_("direction", "Direction", CW), num_("entry", "Entry point", "Start vertex of a closed path", 0)] },
  vcarve: { label: "Vcarve", tools: ["vbit"], base: { faces: true, hint: "Faces whose outlines are carved, or a saved sketch with closed loops, or a text" }, depths: true, sketch: true, text: true,
    fields: [num_("discretize", "Discretize (mm)", "Step along the outline for the centre lines", 0.2), num_("threshold", "Threshold", "Centre lines of the inner corners dropped below this (0..0.9)", 0.25), num_("colinear", "Colinear filter (mm)", "", 0.01)] },
  undercut: { label: "Undercut", tools: ["dovetail"], base: { faces: true, kinds: ["undercut"], required: true, hint: "Undercut faces: inclined faces with the material above them, straight and open at both ends" }, depths: false,
    fields: [num_("stepover", "Step over (mm)", "Step of the roughing passes into the undercut", 1), num_("allowance", "Allowance (mm)", "Left by the roughing passes and removed by the finish pass", 0.2), num_("runout", "Run-out (mm)", "Cutter beyond the face ends", 2), chk_("reverse", "Reverse")] },
  pocket3d: { label: "3D Pocket", tools: ["endmill", "bullnose", "ballend"], base: { faces: true, required: true, hint: "Faces: the volume above them is cleared" }, depths: true,
    fields: [sel_("boundary", "Boundary", [["faces", "Picked faces"], ["stock", "Stock"]]), sel_("pattern", "Pattern", PATTERNS), num_("stepover_pct", "Step over (% of D)", "", 40), num_("angle", "Angle (deg)", "", 0),
             num_("sample", "Sample interval (mm)", "Grid of the height map", 0.5), num_("depth_offset", "Depth offset (mm)", "Left on the surface", 0), sel_("cut_mode", "Cut mode", CW), sel_("entry", "Entry", [["helix", "Helix"], ["plunge", "Plunge"]]), num_("helix_pitch", "Helix pitch (mm)", "", 1)] },
  surface: { label: "3D Surface", tools: ["ballend", "bullnose", "endmill"], base: { faces: true, hint: "Faces of the area (with Boundary: faces); none: the stock" }, depths: true,
    fields: [sel_("boundary", "Boundary", [["stock", "Stock"], ["faces", "Picked faces"]]), num_("boundary_adjust", "Boundary adjust (mm)", "Positive: outward", 0), sel_("boundary_shape", "Boundary shape", [["faces", "Faces"], ["boundbox", "Bounding box"]]),
             sel_("pattern", "Pattern", [["zigzag", "ZigZag"], ["line", "Line"], ["circular", "Circular"], ["circular_zigzag", "Circular ZigZag"], ["offset", "Offset"], ["spiral", "Spiral"]]), num_("angle", "Angle (deg)", "", 0),
             num_("stepover_pct", "Step over (% of D)", "", 25), num_("sample", "Sample interval (mm)", "Grid of the height map and step along the lines", 0.5), num_("depth_offset", "Depth offset (mm)", "Left on the surface", 0),
             sel_("layer", "Layer mode", [["single", "Single pass"], ["multi", "Multi pass"]]), chk_("optimize", "Optimize", "Collinear points removed", true), chk_("boundary_enforce", "Boundary enforcement", "", true)] },
  waterline: { label: "Waterline", tools: ["endmill", "ballend", "bullnose"], base: { faces: true, hint: "Faces of the area (with Boundary: faces); none: the stock" }, depths: true,
    fields: [sel_("boundary", "Boundary", [["stock", "Stock"], ["faces", "Picked faces"]]), num_("boundary_adjust", "Boundary adjust (mm)", "", 0), num_("sample", "Sample interval (mm)", "", 0.5), num_("depth_offset", "Depth offset (mm)", "", 0),
             sel_("cut_mode", "Cut mode", CW), chk_("optimize", "Optimize", "", true), chk_("clear_last", "Clear last level", "The last level cleared as a pocket")] },
  fixture: { label: "Fixture", supplemental: true, fields: [sel_("fixture", "Work offset", ["G54", "G55", "G56", "G57", "G58", "G59"].map(g => [g, g])), num_("sx", "Shift X (mm)", "Estlcam: the coordinates shifted", 0), num_("sy", "Shift Y (mm)", "", 0), num_("sz", "Shift Z (mm)", "", 0)] },
  comment: { label: "Comment", supplemental: true, fields: [txt_("text", "Text")] },
  stop: { label: "Stop", supplemental: true, fields: [chk_("optional", "Optional stop (M01)")] },
  custom: { label: "Custom", supplemental: true, fields: [area_("gcode", "G-code", "Lines written as they are")] },
  copy: { label: "Copy", derived: true, fields: [sel_("of", "Operation", [])] },
  array: { label: "Array", derived: true, fields: [sel_("of", "Operation", []), sel_("kind", "Type", [["linear", "Linear"], ["polar", "Polar"]]), num_("count", "Copies", "Including the base position", 2),
           num_("dx", "Offset X (mm)", "", 20), num_("dy", "Offset Y (mm)", "", 0), num_("angle", "Angle (deg)", "Polar: total angle", 360), num_("cx", "Centre X (mm)", "", 0), num_("cy", "Centre Y (mm)", "", 0)] },
};
const DRESSUPS = {
  tag: { label: "Tag", fields: [num_("count", "Tags", "Tags spaced along the closed path", 4), num_("width", "Width (mm)", "", 6), num_("height", "Height (mm)", "", 2), num_("angle", "Angle (deg)", "Of the flanks; 90: vertical", 45)] },
  ramp: { label: "Ramp entry", fields: [sel_("method", "Method", [["ramp1", "RampMethod1 (ramp, back at the level)"], ["ramp2", "RampMethod2 (ramp then feed on)"], ["zigzag", "ZigZag"], ["helix", "Helix"]]), num_("angle", "Angle (deg)", "", 3), chk_("use_start_depth", "Ramp from the start depth"), num_("feed", "Ramp feed (mm/min)", "Empty: the plunge feed")] },
  leadinout: { label: "Lead in/out", fields: [sel_("style", "Style", [["arc", "Arc"], ["tangent", "Tangent"], ["perpendicular", "Perpendicular"]]), num_("length", "Length (mm)", "Radius of the arc or length of the line", 5), chk_("lead_in", "Lead in", "", true), chk_("lead_out", "Lead out", "", true), num_("extend", "Extend (mm)", "", 0)] },
  dogbone: { label: "Dogbone", fields: [sel_("style", "Style", [["dogbone", "Dogbone"], ["tbone_h", "T-bone horizontal"], ["tbone_v", "T-bone vertical"], ["tbone_long", "T-bone long edge"], ["tbone_short", "T-bone short edge"]]), sel_("side", "Side", [["left", "Left"], ["right", "Right"]]),
             sel_("incision", "Incision", [["adaptive", "Adaptive"], ["fixed", "Fixed"], ["custom", "Custom"]]), num_("length", "Length (mm)", "Custom incision", 0)] },
  boundary: { label: "Boundary", fields: [num_("xmin", "X min (mm)"), num_("xmax", "X max (mm)"), num_("ymin", "Y min (mm)"), num_("ymax", "Y max (mm)"), chk_("inside", "Keep inside", "", true)] },
};
const ORIGIN_XY = [["stock_min", "Stock corner (min X, min Y)"], ["stock_centre", "Stock centre"], ["part", "Part origin"], ["point", "Picked vertex"]];
const ORIGIN_Z = [["stock_top", "Stock top"], ["stock_bottom", "Stock bottom (table)"], ["part", "Part origin"], ["point", "Picked vertex"]];
const BIT_COLS = [["id", "Id"], ["name", "Name"], ["shape", "Shape"], ["d", "D (mm)"], ["corner", "Corner r (mm)"], ["angle", "Angle (deg)"], ["tip", "Tip (mm)"], ["height", "Cut. height (mm)"],
                  ["neck", "Neck (mm)"], ["neck_length", "Neck len. (mm)"], ["shank", "Shank (mm)"], ["shank_length", "Shank len. (mm)"], ["flutes", "Flutes"], ["tool_material", "Tool mat."], ["feed", "Feed (mm/min)"], ["plunge", "Plunge (mm/min)"], ["rpm", "rpm"]];
const TOOL_MATS = [["carbide", "Carbide"], ["hss", "HSS"]];
const SHAPES = [["endmill", "End mill"], ["ballend", "Ball end mill"], ["bullnose", "Bull nose"], ["vbit", "V bit"], ["chamfer", "Chamfer"], ["drill", "Drill"], ["dovetail", "Dovetail"]];
const DEPTH_FIELDS = [["start_depth", "Start depth (mm)", "Top of the cut in part coordinates; empty: the stock top (the floor top for pockets)"], ["final_depth", "Final depth (mm)", "Bottom of the cut; empty: from the geometry"],
                      ["step_down", "Step down (mm)", "Depth of a level; empty: the setup sheet"], ["finish_depth", "Finish depth (mm)", "Height of the last level; empty: the setup sheet"]];
const HEIGHT_FIELDS = [["clearance_height", "Clearance height (mm)", "Rapid moves between operations; empty: start depth + the setup sheet offset"], ["safe_height", "Safe height (mm)", "Rapid moves inside the operation; empty: start depth + the setup sheet offset"]];

function blankDoc(name) {
  return { name: name || "cam", source: { type: "part", name: "" }, stock: { kind: "offsets", xneg: 1, xpos: 1, yneg: 1, ypos: 1, zneg: 0, zpos: 1 },
           origin: { xy: "stock_min", z: "stock_top" }, setup: Object.assign({}, (CM.meta && CM.meta.setup) || { clearance_offset: 5, safe_offset: 3, step_down: 2, finish_depth: 0, hrapid: 3000, vrapid: 1000, coolant: "none" }),
           tools: [], post: "estlcam", output: { folder: "", name: "" }, operations: [], next: 1 };
}
function nid(p) { return p + (CM.doc.next++); }
function opOf(id) { return (CM.doc.operations || []).find(o => o.id === id); }
function opIndex(id) { return (CM.doc.operations || []).findIndex(o => o.id === id); }
function tcOf(id) { return (CM.doc.tools || []).find(t => t.id === id); }
function bitOf(id) { return CM.bits.find(t => t.id === id); }
function bitOfTc(tcid) { const tc = tcOf(tcid); return tc ? bitOf(tc.bit) : null; }
function opLabel(o) { return (OPS[o.type] || {}).label || (CM.meta && CM.meta.op_names && CM.meta.op_names[o.type]) || o.type; }
function hasSource() { return !!(CM.doc && CM.doc.source && CM.doc.source.name); }
/** A change of the document: dirty, the result of the last run is stale, a preview is scheduled. */
function changed(preview = true) {
  CM.dirty = true;
  if (FM) FM.render();
  if (preview) schedulePreview();
}

// ------------------------------------------------------------------ 3D view

function initThree() {
  const box = $("#cm-view");
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(window.devicePixelRatio || 1);
  box.insertBefore(renderer.domElement, box.firstChild);
  const scene = new THREE.Scene();
  const camera = new THREE.OrthographicCamera(-100, 100, 100, -100, -100000, 100000);
  camera.up.set(0, 0, 1);
  camera.position.set(200, -200, 200);
  const controls = new TumbleControls(camera, renderer.domElement);
  controls.enableDamping = false;
  controls.screenSpacePanning = true;
  controls.mouseButtons = { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.PAN, RIGHT: THREE.MOUSE.PAN };
  scene.add(new THREE.AmbientLight(0xffffff, 0.6));
  const d1 = new THREE.DirectionalLight(0xffffff, 0.7);
  camera.add(d1);
  d1.position.set(1, 1, 2);
  scene.add(camera);
  const group = new THREE.Group();
  scene.add(group);
  const overlay = new THREE.Group();
  scene.add(overlay);
  updateAxes(scene, null, true);
  CM.three = { renderer, scene, camera, controls, group, overlay, box, zoomed: false, faceMesh: null, edgeLines: [], geos: [] };
  controls.addEventListener("change", render3);
  camera.userData.target = controls.target;
  CM.three.cube = createNavCube(box, camera, viewDir);
  let down = null;
  renderer.domElement.addEventListener("pointerdown", e => { down = [e.clientX, e.clientY]; });
  renderer.domElement.addEventListener("pointermove", e => { if (!e.buttons) hoverView(e); });
  renderer.domElement.addEventListener("pointerleave", () => { clearHover(); render3(); });
  renderer.domElement.addEventListener("contextmenu", e => e.preventDefault());
  renderer.domElement.addEventListener("pointerup", e => {
    if (!down || Math.abs(e.clientX - down[0]) + Math.abs(e.clientY - down[1]) > 4) { down = null; return; }
    down = null;
    if (e.button === 1) { const h = hitAt(e); if (h) { CM.three.controls.setTarget(h.point.clone(), true); render3(); } return; }
    if (e.button === 0) clickView(e);
  });
  new ResizeObserver(resize3).observe(box);
  resize3();
}
function resize3() {
  const t = CM.three;
  if (!t) return;
  const w = t.box.clientWidth || 1, h = t.box.clientHeight || 1;
  t.renderer.setSize(w, h);
  const c = t.camera, half = (c.top - c.bottom) / 2 || 100;
  c.left = -half * w / h; c.right = half * w / h;
  c.updateProjectionMatrix();
  render3();
}
function render3() { const t = CM.three; if (!t) return; t.renderer.render(t.scene, t.camera); if (t.cube) t.cube.render(); }
function viewDir(dir, up) {
  const t = CM.three;
  const dist = t.camera.position.distanceTo(t.controls.target) || 1;
  const d = dir.clone().normalize();
  const cur = new THREE.Vector3(0, 1, 0).applyQuaternion(t.camera.quaternion);
  let best = up, bd = -Infinity;
  for (const a of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
    const v = new THREE.Vector3(...a);
    if (Math.abs(v.dot(d)) > 1e-6) continue;
    const s = v.dot(cur);
    if (s > bd) { bd = s; best = v; }
  }
  t.camera.up.copy(best);
  t.camera.position.copy(t.controls.target.clone().add(d.multiplyScalar(dist)));
  t.controls.update();
  render3();
}
function view(name) {
  const t = CM.three;
  if (!t) return;
  const bb = CM.bbox || [-50, -50, -50, 50, 50, 50];
  const c = new THREE.Vector3((bb[0] + bb[3]) / 2, (bb[1] + bb[4]) / 2, (bb[2] + bb[5]) / 2);
  const size = Math.max(bb[3] - bb[0], bb[4] - bb[1], bb[5] - bb[2], 1);
  const dirs = { iso: [1, -1, 1], front: [0, -1, 0], top: [0, 0, 1], right: [1, 0, 0] };
  if (name !== "fit") {
    const d = new THREE.Vector3(...dirs[name]).normalize();
    t.camera.up.set(0, 0, 1);
    if (name === "top") t.camera.up.set(0, 1, 0);
    t.camera.position.copy(c.clone().add(d.multiplyScalar(size * 4)));
  } else {
    const d = t.camera.position.clone().sub(t.controls.target).normalize();
    t.camera.position.copy(c.clone().add(d.multiplyScalar(size * 4)));
  }
  t.controls.target.copy(c);
  const w = t.box.clientWidth || 1, h = t.box.clientHeight || 1;
  const half = size * 0.75;
  t.camera.top = half; t.camera.bottom = -half; t.camera.left = -half * w / h; t.camera.right = half * w / h;
  t.camera.zoom = 1;
  t.camera.updateProjectionMatrix();
  t.controls.update();
  render3();
}
function rayAt(e) {
  const t = CM.three;
  const r = t.renderer.domElement.getBoundingClientRect();
  const nd = new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
  const rc = new THREE.Raycaster();
  rc.setFromCamera(nd, t.camera);
  rc.params.Line.threshold = (t.camera.right - t.camera.left) / t.camera.zoom / r.width * 6;   // 6 px
  return rc;
}
function hitAt(e) { const t = CM.three; if (!t.faceMesh) return null; const h = rayAt(e).intersectObject(t.faceMesh, false); return h.length ? h[0] : null; }
/** What the cursor is over: {kind: "face", index} | {kind: "edge", index} | null; edges before faces within 6 px
 *  when the active step takes edges. */
function pickAt(e, kinds) {
  const t = CM.three;
  if (!CM.geo || !t.faceMesh) return null;
  const rc = rayAt(e);
  const px = (t.camera.right - t.camera.left) / t.camera.zoom / t.renderer.domElement.getBoundingClientRect().width;
  const fh = rc.intersectObject(t.faceMesh, false);
  const face = fh.length ? { kind: "face", index: CM.geo.face_of_tri[fh[0].faceIndex], dist: fh[0].distance, point: [fh[0].point.x, fh[0].point.y, fh[0].point.z] } : null;
  if (kinds.includes("edge") && t.edgeLines.length) {
    const hits = rc.intersectObjects(t.edgeLines, false);
    for (const h of hits) h.dr = rc.ray.distanceToPoint(h.point);
    hits.sort((a, b) => (Math.abs(a.dr - b.dr) > px * 1.5 ? a.dr - b.dr : a.distance - b.distance));
    if (hits.length && (!face || hits[0].distance < face.dist + px * 3)) return { kind: "edge", index: hits[0].object.userData.index, point: [hits[0].point.x, hits[0].point.y, hits[0].point.z] };
  }
  if (face && (kinds.includes("face") || kinds.includes("point"))) return face;
  return null;
}
function clearHover() {
  const t = CM.three;
  if (!t || !t.hover) return;
  t.scene.remove(t.hover);
  t.hover = null;
  t.renderer.domElement.style.cursor = "";
}
function faceGeo(fi) {
  const m = CM.geo, pos = [];
  m.triangles.forEach((tr, k) => { if (m.face_of_tri[k] === fi) for (const v of tr) pos.push(...m.vertices[v]); });
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  return g;
}
function facesGeo(set) {
  const m = CM.geo, pos = [];
  m.triangles.forEach((tr, k) => { if (set.has(m.face_of_tri[k])) for (const v of tr) pos.push(...m.vertices[v]); });
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  return g;
}
function edgeGeo(set) {
  const m = CM.geo, pos = [];
  m.edges.forEach((pl, i) => { if (set.has(i)) for (let k = 0; k + 1 < pl.length; k++) pos.push(...pl[k], ...pl[k + 1]); });
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  return g;
}
/** The pick step of the command window: {kinds: ["face", "edge", "point"], faceKinds} or null. */
function pickStep() {
  const c = CM.cmd;
  if (c && c.place) return c.pick ? { kinds: ["face"], faceKinds: null, place: true } : null;
  if (!c || c.dr !== undefined) return null;
  const o = opOf(c.id);
  if (!o || c.step !== 0) return null;
  const b = (OPS[o.type] || {}).base;
  if (!b) return null;
  const kinds = [];
  if (b.faces && c.mode !== "edges" && c.mode !== "points") kinds.push("face");
  if (b.edges && c.mode !== "faces" && c.mode !== "points") kinds.push("edge");
  if (b.points && c.mode === "points") kinds.push("point");
  return { kinds, faceKinds: b.kinds || null, points: b.points, op: o };
}
function hoverView(e) {
  if (CM.zeroPick) { hoverZero(e); return; }
  const t = CM.three;
  const ps = pickStep();
  if (!t || !CM.doc || !ps) { if (t) { clearHover(); render3(); } return; }
  clearHover();
  const h = pickAt(e, ps.kinds);
  let ok = false;
  if (h && h.kind === "face" && ps.kinds.includes("face") && (!ps.faceKinds || ps.faceKinds.includes((CM.geo.face_kind || [])[h.index]))) {
    const fm = new THREE.Mesh(faceGeo(h.index), new THREE.MeshBasicMaterial({ color: COLORS.sel, transparent: true, opacity: 0.35, side: THREE.DoubleSide, depthTest: false }));
    fm.renderOrder = 10;
    t.hover = fm; t.scene.add(fm); ok = true;
  } else if (h && h.kind === "edge") {
    const l = new THREE.LineSegments(edgeGeo(new Set([h.index])), new THREE.LineBasicMaterial({ color: COLORS.sel, depthTest: false, linewidth: 3 }));
    l.renderOrder = 10;
    t.hover = l; t.scene.add(l); ok = true;
  } else if (h && ps.kinds.includes("point")) ok = true;
  t.renderer.domElement.style.cursor = ok ? "crosshair" : "";
  render3();
}
/** Index of the face of the geometry a stored face key refers to (nearest centre), or -1. */
function faceIndex(key) {
  if (!CM.geo || !key || !key.c) return -1;
  let best = -1, bd = Infinity;
  CM.geo.face_keys.forEach((k, i) => {
    if (!k) return;
    const d = Math.hypot(k.c[0] - key.c[0], k.c[1] - key.c[1], k.c[2] - key.c[2]);
    if (d < bd) { bd = d; best = i; }
  });
  return bd < 0.05 ? best : -1;
}
function edgeIndex(key) {
  if (!CM.geo || !key || !key.mid) return -1;
  let best = -1, bd = Infinity;
  (CM.geo.edge_keys || []).forEach((k, i) => {
    if (!k || !k.mid) return;
    const d = Math.hypot(k.mid[0] - key.mid[0], k.mid[1] - key.mid[1], k.mid[2] - key.mid[2]);
    if (d < bd) { bd = d; best = i; }
  });
  return bd < 0.05 ? best : -1;
}
function clickView(e) {
  if (CM.zeroPick) { clickZero(e); return; }
  const ps = pickStep();
  if (!ps) { return; }
  const h = pickAt(e, ps.kinds);
  if (!h) return;
  if (ps.place) { if (h.kind === "face") placePick(h.index); return; }
  const op = ps.op;
  if (h.kind === "face" && ps.kinds.includes("point")) {
    const pts = op.points || (op.points = []);
    if (pts.length >= ps.points) pts.length = 0;
    pts.push([Math.round(h.point[0] * 1000) / 1000, Math.round(h.point[1] * 1000) / 1000]);
    status(`${pts.length} of ${ps.points} point(s) of ${op.name}`);
  } else if (h.kind === "face") {
    if (ps.faceKinds && !ps.faceKinds.includes((CM.geo.face_kind || [])[h.index])) { status("Pick " + (OPS[op.type].base.hint || "a face"), true); return; }
    const key = CM.geo.face_keys[h.index];
    const k = (op.faces || []).findIndex(f => faceIndex(f) === h.index);
    if (k >= 0) op.faces.splice(k, 1); else (op.faces = op.faces || []).push({ c: key.c, n: key.n, area: key.area });
    status(`${op.faces.length} face(s) of ${op.name} (click again to deselect)`);
  } else if (h.kind === "edge") {
    const key = CM.geo.edge_keys[h.index];
    const k = (op.edges || []).findIndex(f => edgeIndex(f) === h.index);
    if (k >= 0) op.edges.splice(k, 1); else (op.edges = op.edges || []).push({ mid: key.mid, len: key.len });
    status(`${op.edges.length} edge(s) of ${op.name} (click again to deselect)`);
  }
  changed();
  renderCommand(); drawSelection();
}

// ------------------------------------------------------------------ geometry, setup and preview

async function loadGeometry() {
  const seq = ++CM.seq;
  const src = CM.doc.source || {};
  if (!src.name) { CM.geo = null; CM.res = null; CM.setup = null; $("#cm-info").textContent = "Choose a part"; draw(); renderAll(); return; }
  $("#cm-info").textContent = "Loading the part...";
  try {
    const r = await postJSON("/api/cam/geometry", { cam: CM.doc });
    const g = await r.json();
    if (seq !== CM.seq) return;
    CM.geo = g;
    const nk = k => (g.face_kind || []).filter(x => x === k).length;
    $("#cm-info").textContent = `${src.name}: ${g.face_keys.length} faces (${nk("floor")} floor, ${nk("hole")} hole, ${g.undercuts.length} undercut), ${fmt(g.volume_mm3 / 1000, 4)} cm^3, ${g.bbox ? g.bbox.slice(3).map((v, i) => fmt(v - g.bbox[i], 5)).join(" x ") + " mm" : ""}`;
    if (CM.three) CM.three.zoomed = false;
    await loadSetup();
    draw(); renderAll();
    if ((CM.doc.operations || []).length) schedulePreview(0);
  } catch (e) { if (seq === CM.seq) { CM.geo = null; $("#cm-info").textContent = ""; showErr(e); draw(); renderAll(); } }
}
let setupSeq = 0;
async function loadSetup() {
  const seq = ++setupSeq;
  if (!hasSource()) { CM.setup = null; return; }
  try {
    const su = await (await postJSON("/api/cam/setup", { cam: CM.doc })).json();
    if (seq === setupSeq) CM.setup = su;
  } catch (e) { if (seq === setupSeq) CM.setup = null; }
}
/** Preview after a change: the operations up to the edited one (the whole job when none is edited), 500 ms after
 *  the last change; the earlier operations come from the server cache. */
function schedulePreview(delay = 500) {
  if (CM.previewTimer) clearTimeout(CM.previewTimer);
  CM.previewTimer = setTimeout(runPreview, delay);
}
async function runPreview() {
  CM.previewTimer = null;
  if (!hasSource() || !(CM.doc.operations || []).length) { CM.res = null; draw(); renderTree(); renderProps(); return; }
  const upto = CM.cmd && CM.cmd.id ? opIndex(CM.cmd.id) : null;
  const seq = ++CM.previewSeq;
  $("#cm-info").textContent = "Computing the toolpaths...";
  try {
    const r = await postJSON("/api/cam/run", { cam: CM.doc, upto, meshes: true });
    const res = await r.json();
    if (seq !== CM.previewSeq) return;
    CM.res = res; CM.resUpto = upto;
    const bad = res.operations.filter(o => !o.ok);
    $("#cm-info").textContent = bad.length ? `${bad[0].name}: ${bad[0].errors[0]}` : `${res.operations.length} operation(s), ${fmt(res.operations.reduce((s, o) => s + (o.time_s || 0), 0) / 60, 3)} min`;
  } catch (e) { if (seq === CM.previewSeq) { CM.res = null; $("#cm-info").textContent = e.message || String(e); } }
  renderTree(); renderProps(); renderCommand(); draw();
}

function clearView() {
  const t = CM.three;
  for (const g of t.geos) g.dispose();
  t.geos = [];
  t.group.clear();
  t.faceMesh = null; t.edgeLines = [];
}
function track(g) { CM.three.geos.push(g); return g; }
function meshGeo(m) {
  const geo = track(new THREE.BufferGeometry());
  geo.setAttribute("position", new THREE.Float32BufferAttribute(m.vertices.flat(), 3));
  geo.setIndex(m.triangles.flat());
  geo.computeVertexNormals();
  geo.computeBoundingBox();
  const pos = [];
  for (const pl of m.edges || []) for (let k = 0; k + 1 < pl.length; k++) pos.push(...pl[k], ...pl[k + 1]);
  const edgeGeo = track(new THREE.BufferGeometry());
  edgeGeo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  return { geo, edgeGeo };
}
function addMesh(m, color, opts) {
  const t = CM.three;
  const { geo, edgeGeo } = meshGeo(m);
  const mat = new THREE.MeshStandardMaterial(Object.assign({ color, metalness: 0.1, roughness: 0.7, side: THREE.DoubleSide,
                                                             polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1 }, opts || {}));
  const mesh = new THREE.Mesh(geo, mat);
  t.group.add(mesh);
  if ($("#cm-edges").checked && (m.edges || []).length) t.group.add(new THREE.LineSegments(edgeGeo, new THREE.LineBasicMaterial({ color: 0x1d2125, transparent: !!(opts && opts.transparent), opacity: opts && opts.transparent ? 0.3 : 1 })));
  return mesh;
}
/** The moves of an operation record as line segments by kind. */
function pathSegments(moves, segs) {
  let prev = null;
  for (const m of moves || []) {
    if (!m.p) continue;
    if (prev) {
      if (m.k === "arc") { let q = prev; for (const a of arcPoints(prev, m.p, m.c, m.cw)) { segs.arc.push(...q, ...a); q = a; } }
      else (segs[m.k] || segs.feed).push(...prev, ...m.p);
    }
    prev = m.p;
  }
}
/** Everything in the view: the part (faces of the kind being picked tinted), the stock outline and the machine
 *  zero, the stock and the remaining material after the operations, the toolpaths (the edited operation in full
 *  colour, the others dimmed while a command is open). */
function draw() {
  const t = CM.three;
  if (!t) return;
  clearHover();
  clearView();
  const box = new THREE.Box3();
  if (CM.geo && $("#cm-showpart").checked && !CM.hidden.model && !CM.hidden.job) {
    const mesh = addMesh(CM.geo, COLORS.part);
    t.faceMesh = mesh;
    box.expandByObject(mesh);
    const ps = pickStep();
    if (ps && ps.kinds.includes("edge")) {
      // the edges as pickable lines
      CM.geo.edges.forEach((pl, i) => {
        if (pl.length < 2) return;
        const g = track(new THREE.BufferGeometry());
        g.setAttribute("position", new THREE.Float32BufferAttribute(pl.flat(), 3));
        const l = new THREE.Line(g, new THREE.LineBasicMaterial({ color: 0x1d2125 }));
        l.userData = { index: i };
        t.group.add(l); t.edgeLines.push(l);
      });
    }
    const under = new Set($("#cm-showunder").checked ? CM.geo.undercuts || [] : []);
    if (ps && ps.faceKinds) (CM.geo.face_kind || []).forEach((k, i) => { if (ps.faceKinds.includes(k)) under.add(i); });
    if (under.size) {
      const fm = new THREE.Mesh(track(facesGeo(under)), new THREE.MeshBasicMaterial({ color: ps && ps.faceKinds ? COLORS.pickable : COLORS.under, transparent: true, opacity: 0.3, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }));
      t.group.add(fm);
    }
  }
  const su = CM.setup;
  if (su && su.stock_bbox && !CM.hidden.stock && !CM.hidden.job) {
    const b = su.stock_bbox, pos = [];
    const c = [[b[0], b[1]], [b[3], b[1]], [b[3], b[4]], [b[0], b[4]]];
    for (let k = 0; k < 4; k++) {
      const p = c[k], q = c[(k + 1) % 4];
      pos.push(p[0], p[1], b[2], q[0], q[1], b[2], p[0], p[1], b[5], q[0], q[1], b[5], p[0], p[1], b[2], p[0], p[1], b[5]);
    }
    const g = track(new THREE.BufferGeometry());
    g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    const l = new THREE.LineSegments(g, new THREE.LineDashedMaterial({ color: 0x5c7cfa, dashSize: 2, gapSize: 1.5 }));
    l.computeLineDistances();
    t.group.add(l);
    box.expandByObject(l);
  }
  if (su && su.origin && !CM.hidden.job) {
    const o = su.origin, b = su.stock_bbox, s = Math.max(5, Math.min(b[3] - b[0], b[4] - b[1]) * 0.15);
    for (const [d, col] of [[[1, 0, 0], 0xe03131], [[0, 1, 0], 0x2b8a3e], [[0, 0, 1], 0x1c7ed6]]) {
      const ga = track(new THREE.BufferGeometry());
      ga.setAttribute("position", new THREE.Float32BufferAttribute([o[0], o[1], o[2], o[0] + d[0] * s, o[1] + d[1] * s, o[2] + d[2] * s], 3));
      const la = new THREE.Line(ga, new THREE.LineBasicMaterial({ color: col, depthTest: false, linewidth: 2 }));
      la.renderOrder = 6;
      t.group.add(la);
    }
  }
  const r = CM.res;
  if (r) {
    if ($("#cm-showstock").checked && !CM.hidden.stock && !CM.hidden.job && r.stock_mesh && r.stock_mesh.triangles.length) box.expandByObject(addMesh(r.stock_mesh, COLORS.stock, { transparent: true, opacity: 0.25, depthWrite: false }));
    if ($("#cm-showleft").checked && !CM.hidden.job && r.left_mesh && r.left_mesh.triangles.length) box.expandByObject(addMesh(r.left_mesh, COLORS.left));
    if ($("#cm-showhm").checked) for (const op of r.operations) {
      if (op.hm && op.hm.mesh && op.hm.mesh.triangles.length && !hiddenItem(op.id)) box.expandByObject(addMesh(op.hm.mesh, COLORS.hm, { transparent: true, opacity: 0.6 }));
    }
    if ($("#cm-showpath").checked) {
      const cur = CM.cmd ? CM.cmd.id : null;
      const full = { rapid: [], plunge: [], feed: [], arc: [] }, dim = { rapid: [], plunge: [], feed: [], arc: [] };
      for (const op of r.operations) {
        if (hiddenItem(op.id)) continue;
        pathSegments(op.moves, cur && op.id !== cur ? dim : full);
      }
      for (const [segs, dimmed] of [[dim, true], [full, false]]) for (const k of Object.keys(segs)) {
        if (!segs[k].length || (k === "rapid" && !$("#cm-showrapid").checked)) continue;
        const g = track(new THREE.BufferGeometry());
        g.setAttribute("position", new THREE.Float32BufferAttribute(segs[k], 3));
        const l = new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: dimmed ? COLORS.dim : COLORS[k], depthTest: k === "rapid" || k === "plunge", transparent: dimmed, opacity: dimmed ? 0.5 : 1 }));
        l.renderOrder = 5;
        t.group.add(l);
        box.expandByObject(l);
      }
    }
  }
  if (CM.cmd && CM.cmd.place) drawDatums(box);
  t.group.updateMatrixWorld(true);
  const bb = box.isEmpty() ? null : [box.min.x, box.min.y, box.min.z, box.max.x, box.max.y, box.max.z];
  CM.bbox = bb;
  if (bb) CM.size = Math.max(bb[3] - bb[0], bb[4] - bb[1], bb[5] - bb[2], 1);
  updateAxes(t.scene, bb, $("#cm-axes").checked);
  drawSelection(false);
  if (!t.zoomed && bb) { view("iso"); t.zoomed = true; } else render3();
}
/** The faces, edges and points of the selected or edited operation, and the chip under the mouse, as an overlay. */
function drawSelection(doRender = true) {
  const t = CM.three;
  if (!t) return;
  t.overlay.clear();
  const id = CM.cmd ? CM.cmd.id : CM.sel;
  const op = id && opOf(id);
  const pcs = (CM.doc && CM.doc.placement && CM.doc.placement.constraints) || [];
  const pcSel = CM.cmd && CM.cmd.place ? pcs : CM.sel && CM.sel.startsWith("pc:") ? pcs.filter(c => "pc:" + c.id === CM.sel) : [];
  if (pcSel.length && CM.geo && t.faceMesh) {
    const hv = CM.chipHover && CM.chipHover.pc;
    const fs = new Set(pcSel.filter(c => !c.suppressed && c.id !== hv).map(c => +c.face).filter(i => i >= 0 && i < CM.geo.face_keys.length));
    if (fs.size) t.overlay.add(new THREE.Mesh(facesGeo(fs), new THREE.MeshBasicMaterial({ color: COLORS.sel, transparent: true, opacity: 0.45, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 })));
    const hc = hv && pcs.find(c => c.id === hv);
    if (hc) { const fm = new THREE.Mesh(faceGeo(+hc.face), new THREE.MeshBasicMaterial({ color: 0xffd43b, transparent: true, opacity: 0.7, side: THREE.DoubleSide, depthTest: false })); fm.renderOrder = 11; t.overlay.add(fm); }
  }
  if (op && CM.geo && t.faceMesh) {
    const fs = new Set((op.faces || []).map(faceIndex).filter(i => i >= 0));
    const es = new Set((op.edges || []).map(edgeIndex).filter(i => i >= 0));
    if (fs.size) {
      const fm = new THREE.Mesh(facesGeo(fs), new THREE.MeshBasicMaterial({ color: COLORS.sel, transparent: true, opacity: 0.55, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 }));
      t.overlay.add(fm);
    }
    if (es.size) {
      const l = new THREE.LineSegments(edgeGeo(es), new THREE.LineBasicMaterial({ color: COLORS.edgeSel, depthTest: false, linewidth: 3 }));
      l.renderOrder = 9;
      t.overlay.add(l);
    }
    const hv = CM.chipHover;
    if (hv) {
      const fi = faceIndex(hv), ei = edgeIndex(hv);
      if (fi >= 0) { const fm = new THREE.Mesh(faceGeo(fi), new THREE.MeshBasicMaterial({ color: 0xffd43b, transparent: true, opacity: 0.6, side: THREE.DoubleSide, depthTest: false })); fm.renderOrder = 11; t.overlay.add(fm); }
      if (ei >= 0) { const l = new THREE.LineSegments(edgeGeo(new Set([ei])), new THREE.LineBasicMaterial({ color: 0xffd43b, depthTest: false })); l.renderOrder = 11; t.overlay.add(l); }
    }
    if (op.points && op.points.length) {
      const z = CM.geo.bbox ? CM.geo.bbox[5] : 0;
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.Float32BufferAttribute(op.points.flatMap(p => [p[0], p[1], z]), 3));
      const pm = new THREE.Points(g, new THREE.PointsMaterial({ color: COLORS.sel, size: 8, sizeAttenuation: false, depthTest: false }));
      pm.renderOrder = 11;
      t.overlay.add(pm);
    }
  }
  if (doRender) render3();
}

// ------------------------------------------------------------------ side panel: job tree

function bindPanelSplit() {
  const bar = $("#cm-split"), panel = $("#cm-panel");
  if (!bar || bar.dataset.bound) return;
  bar.dataset.bound = "1";
  try { const w = +localStorage.getItem("cm_panel_w"); if (w >= 300) panel.style.width = w + "px"; } catch (e) { /* no storage */ }
  bar.onmousedown = e => {
    e.preventDefault();
    const w0 = panel.getBoundingClientRect().width, x0 = e.clientX;
    bar.classList.add("drag");
    const move = ev => { panel.style.width = Math.max(300, Math.min(window.innerWidth * 0.75, w0 + x0 - ev.clientX)) + "px"; };
    const up = () => {
      bar.classList.remove("drag");
      window.removeEventListener("mousemove", move); window.removeEventListener("mouseup", up);
      try { localStorage.setItem("cm_panel_w", parseInt(panel.style.width)); } catch (err) { /* no storage */ }
    };
    window.addEventListener("mousemove", move); window.addEventListener("mouseup", up);
  };
}
function renderAll() {
  if (!CM.doc) return;
  bindPanelSplit();
  renderTree(); renderProps(); renderBits(); renderPost();
}
const EYE = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>`;
const ico = (key, alt) => (window.treeIcon && window.treeIcon(key)) || `<span class="ico">${alt || "•"}</span>`;
const OP_ICON = t => ({ copy: "copy", array: "pattern" })[t] || "cam_" + t;
const PC_ICON = { coincident: "mate_coincident", distance: "mate_distance", parallel: "mate_parallel", angle: "mate_angle", concentric: "mate_concentric" };
function recOf(id) { return CM.res && CM.res.operations.find(x => x.id === id); }
/** Hidden in the view: the item or the Job. */
function hiddenItem(id) { return !!(CM.hidden.job || CM.hidden[id] || (id !== "model" && id !== "stock" && id !== "job" && CM.hidden.ops && opOf(id))); }
/** The job tree in the manner of the FreeCAD CAM workbench: Job with Operations, Model (the part and its placement
 *  constraints), Stock, SetupSheet and Tools (tool controllers); folders fold, eyes hide geometry. */
function renderTree() {
  const d = CM.doc, box = $("#cm-tree");
  const fold = CM.fold;
  const row = (id, level, icon, name, o) => {
    o = o || {};
    const tw = o.kids === undefined ? `<span class="cm-tw"></span>` : `<span class="cm-tw${o.kids ? "" : " none"}" data-k="fold">${o.kids ? (fold[id] ? "▸" : "▾") : ""}</span>`;
    const eye = o.eye ? `<button type="button" data-k="eye" class="cm-eye${CM.hidden[id] ? " off" : ""}" title="Show / hide">${EYE}</button>` : `<span class="cm-eye"></span>`;
    return `<div class="pt-feat cm-tr${id === CM.sel ? " sel" : ""}${o.supp ? " supp" : ""}${o.cmd ? " editing" : ""}${level >= 2 ? " cm-child" : ""}${o.dim ? " hid" : ""}" data-id="${esc(id)}" style="padding-left:${4 + level * 16}px">` +
      `<span class="cm-lead">${tw}${eye}${o.toggle ? `<input type="checkbox" data-k="on" title="Active"${o.supp ? "" : " checked"}>` : ""}${icon}</span>` +
      `<span class="nm">${esc(name)}${o.sub ? ` <span class="hint">${esc(o.sub)}</span>` : ""}${o.state || ""}</span>` +
      `<span class="ops">` + (o.ops ? `<button type="button" data-k="up" title="Move up">&#9650;</button><button type="button" data-k="down" title="Move down">&#9660;</button>` : "") +
      (o.del ? `<button type="button" data-k="del" title="Delete">&#10005;</button>` : "") + `</span>` +
      (o.err ? `<span class="err">${esc(o.err)}</span>` : "") + "</div>";
  };
  const ops = d.operations || [], tcs = d.tools || [], pl = d.placement || {}, pcs = pl.constraints || [];
  const hj = !!CM.hidden.job;
  let h = row("job", 0, ico("cam_job"), d.name || "Job", { kids: true, eye: true, dim: hj, sub: `${(CM.posts.find(p => p.id === d.post) || {}).name || d.post || ""}` });
  if (!fold.job) {
    h += row("ops", 1, ico("cam_folder"), "Operations", { kids: ops.length > 0, eye: true, dim: hj || CM.hidden.ops, sub: ops.length ? `${ops.length}` : "" });
    if (!fold.ops) ops.forEach(o => {
      const r = recOf(o.id), ot = OPS[o.type] || {};
      const state = !r ? "" : r.ok ? (r.gouge_mm3 > 0.05 ? ` <span class="cm-warn" title="gouge">⚠</span>` : ` <span class="cm-ok">✓</span>`) : ` <span class="cm-err">✗</span>`;
      const sub = ot.supplemental ? "" : ot.derived ? `of ${(opOf(o.of) || {}).name || "?"}` : (o.tc || "no tool") + ((ot.base && (o.faces || []).length) ? `, ${o.faces.length} face(s)` : "") + ((o.edges || []).length ? `, ${o.edges.length} edge(s)` : "");
      const drs = o.dressups || [];
      h += row(o.id, 2, ico(OP_ICON(o.type), "⟲"), o.name, { kids: drs.length > 0, toggle: true, ops: true, del: true, supp: o.active === false, eye: !ot.supplemental, dim: hiddenItem(o.id),
                                                             sub: `${opLabel(o)}${sub ? ", " + sub : ""}`, state, cmd: CM.cmd && CM.cmd.id === o.id && CM.cmd.dr === undefined, err: r && !r.ok && r.errors && r.errors[0] });
      if (!fold[o.id]) drs.forEach((dr, k) => {
        const id = `dr:${o.id}:${k}`;
        h += row(id, 3, ico("cam_dr_" + dr.type, "✧"), (DRESSUPS[dr.type] || {}).label || dr.type, { del: true, cmd: CM.cmd && CM.cmd.id === o.id && CM.cmd.dr === k });
      });
    });
    const src = d.source && d.source.name;
    h += row("model", 1, ico("cam_folder"), "Model", { kids: !!src, eye: true, dim: hj || CM.hidden.model, cmd: CM.cmd && CM.cmd.place });
    if (!fold.model && src) {
      h += row("part", 2, ico("cam_model"), src, { kids: pcs.length > 0, dim: hj || CM.hidden.model, sub: placementText(pl) });
      if (!fold.part) pcs.forEach(c => {
        const bad = CM.placeRes && (CM.placeRes.unsatisfied || {})[c.id];
        h += row("pc:" + c.id, 3, ico(PC_ICON[c.type], "⊥"), pcLabel(c), { del: true, supp: !!c.suppressed, err: bad || "" });
      });
    }
    h += row("stock", 1, ico("cam_stock"), "Stock", { eye: true, dim: hj || CM.hidden.stock, sub: stockText() });
    h += row("setup", 1, ico("cam_sheet"), "SetupSheet");
    h += row("tools", 1, ico("cam_folder"), "Tools", { kids: tcs.length > 0, sub: `${tcs.length}` });
    if (!fold.tools) for (const tc of tcs) {
      const b = bitOf(tc.bit);
      h += row("tc:" + tc.id, 2, ico("cam_tool", "⚙"), `${tc.id} ${tc.name || ""}`, { sub: `T${tc.number} ${b ? fmt(b.d) + " mm" : "(no bit: " + tc.bit + ")"}`, del: true });
    }
  }
  box.innerHTML = h;
  box.querySelectorAll(".pt-feat").forEach(el => {
    const id = el.dataset.id;
    el.onclick = e => {
      const kEl = e.target.closest("[data-k]"), k = kEl && kEl.dataset.k;
      if (k === "fold") { fold[id] = !fold[id]; saveFold(); renderTree(); return; }
      if (k === "eye") { CM.hidden[id] = !CM.hidden[id]; renderTree(); draw(); return; }
      if (id.startsWith("tc:")) {
        if (k === "del") { deleteTc(id.slice(3)); return; }
        select(id); return;
      }
      if (id.startsWith("pc:")) {
        if (k === "del") { deleteConstraint(id.slice(3)); return; }
        select(id); return;
      }
      if (id.startsWith("dr:")) {
        const [, oid, k2] = id.split(":");
        if (k === "del") { const o = opOf(oid); o.dressups.splice(+k2, 1); if (CM.cmd && CM.cmd.id === oid) closeCommand(false); changed(); renderAll(); return; }
        select(id); return;
      }
      const o = opOf(id);
      if (!o) { select(id); return; }
      const i = opIndex(id);
      if (k === "on") { o.active = e.target.checked; changed(); renderTree(); return; }
      if (k === "up" && i > 0) { [ops[i - 1], ops[i]] = [ops[i], ops[i - 1]]; changed(); renderTree(); return; }
      if (k === "down" && i < ops.length - 1) { [ops[i + 1], ops[i]] = [ops[i], ops[i + 1]]; changed(); renderTree(); return; }
      if (k === "del") { deleteOp(id); return; }
      select(id);
    };
    el.ondblclick = e => {
      if (e.target.closest("[data-k]")) return;
      if (id.startsWith("dr:")) { const [, oid, k2] = id.split(":"); openCommand(oid, +k2); return; }
      if (id === "model" || id === "part" || id.startsWith("pc:")) { openPlacement(); return; }
      if (["job", "ops", "tools"].includes(id)) { fold[id] = !fold[id]; saveFold(); renderTree(); return; }
      if (opOf(id)) openCommand(id);
    };
  });
}
function saveFold() { try { localStorage.setItem("cm-fold", JSON.stringify(CM.fold)); } catch (e) { /* this session */ } }
function placementText(pl) {
  const p = (pl && pl.pos) || [0, 0, 0], r = (pl && pl.rot) || [0, 0, 0];
  if (![...p, ...r].some(v => Math.abs(v) > 1e-9)) return "not moved";
  return `at ${p.map(v => fmt(v, 5)).join(", ")} mm, turned ${r.map(v => fmt(v, 4)).join(", ")} deg`;
}
function pcLabel(c) {
  const t = (PC_TYPES.find(x => x[0] === c.type) || [0, c.type])[1];
  return `${t} face ${(+c.face) + 1} / ${c.datum || "?"}${c.type === "distance" ? ` ${fmt(c.value)} mm` : c.type === "angle" ? ` ${fmt(c.value)} deg` : ""}${c.flip ? ", flipped" : ""}`;
}
function stockText() {
  const st = CM.doc.stock || {}, m = st.material ? materialName(st.material) : "";
  return stockShape(st) + (m ? ", " + m : "");
}
function stockShape(st) {
  if (st.kind === "part_filled") return "part with the undercuts filled";
  if (st.kind === "box") return "box";
  return `offsets ${fmt(st.xneg)}/${fmt(st.xpos)} ${fmt(st.yneg)}/${fmt(st.ypos)} ${fmt(st.zneg)}/${fmt(st.zpos)} mm`;
}
function select(id) {
  CM.sel = id;
  renderTree(); renderProps(); drawSelection();
}
function deleteOp(id) {
  const o = opOf(id);
  if (!o || !confirm(`Delete ${o.name}?`)) return;
  if (CM.cmd && CM.cmd.id === id) closeCommand(false);
  CM.doc.operations = CM.doc.operations.filter(x => x.id !== id);
  // copies and arrays of the operation lose their source
  for (const x of CM.doc.operations) if (x.of === id) x.of = "";
  if (CM.sel === id) CM.sel = null;
  changed(); renderAll(); draw();
}
function deleteTc(id) {
  const used = (CM.doc.operations || []).filter(o => o.tc === id);
  if (!confirm(`Delete tool controller ${id}?${used.length ? ` ${used.length} operation(s) use it.` : ""}`)) return;
  CM.doc.tools = CM.doc.tools.filter(t => t.id !== id);
  if (CM.sel === "tc:" + id) CM.sel = "tools";
  changed(); renderAll();
}

// ------------------------------------------------------------------ side panel: properties

const numField = (label, k, v, title, cls = "numf") => `<label class="cm-f"${title ? ` title="${esc(title)}"` : ""}>${esc(label)}<input type="text" class="${cls}" data-k="${k}" value="${v === null || v === undefined ? "" : esc(typeof v === "number" ? fmt(v, 6) : v)}"></label>`;
const selField = (label, k, cur, list, title) => `<label class="cm-f"${title ? ` title="${esc(title)}"` : ""}>${esc(label)}<select data-k="${k}">${list.map(([v, l]) => `<option value="${esc(v)}"${String(v) === String(cur) ? " selected" : ""}>${esc(l)}</option>`).join("")}</select></label>`;
const chkField = (label, k, cur, title) => `<label class="check inline"${title ? ` title="${esc(title)}"` : ""}><input type="checkbox" data-k="${k}"${cur ? " checked" : ""}> ${esc(label)}</label>`;
/** Binds the fields of a form (data-k) to an object: numbers (empty: null when allowNull), selects, checkboxes, text. */
function bindFields(box, obj, onChange, allowNull = true) {
  for (const inp of box.querySelectorAll("[data-k]")) inp.onchange = () => {
    const k = inp.dataset.k;
    if (inp.tagName === "SELECT") obj[k] = inp.value;
    else if (inp.type === "checkbox") obj[k] = inp.checked;
    else if (inp.classList.contains("numf")) {
      if (inp.value.trim() === "") { if (allowNull) obj[k] = null; else { inp.value = fmt(obj[k], 6); return; } }
      else { const v = num(inp.value); if (!isFinite(v)) { inp.value = obj[k] === null || obj[k] === undefined ? "" : fmt(obj[k], 6); return; } obj[k] = v; }
    } else obj[k] = inp.value;
    onChange(k);
  };
}

function renderProps() {
  const box = $("#cm-props"), d = CM.doc, id = CM.sel;
  if (!d) return;
  if (!id) { box.innerHTML = `<p class="hint">Select an item of the job tree. Double-click an operation to edit it in the command window.</p>`; return; }
  if (id === "model" || id === "part") return renderModelProps(box);
  if (id === "job" || id === "output") return renderJobProps(box);
  if (id === "ops") return renderOpsProps(box);
  if (id.startsWith("pc:")) return renderPcProps(box, id.slice(3));
  if (id === "stock") return renderStockProps(box);
  if (id === "setup") return renderSetupProps(box);
  if (id === "tools") return renderToolsProps(box);
  if (id.startsWith("tc:")) return renderTcProps(box, id.slice(3));
  if (id.startsWith("dr:")) { const [, oid, k] = id.split(":"); const o = opOf(oid); const dr = o && (o.dressups || [])[+k]; if (!dr) { CM.sel = null; return renderProps(); } box.innerHTML = `<div class="row"><strong>${esc((DRESSUPS[dr.type] || {}).label || dr.type)}</strong> of ${esc(o.name)}</div><div class="row"><button type="button" id="cm-edit">Edit</button></div>`; $("#cm-edit").onclick = () => openCommand(oid, +k); return; }
  const o = opOf(id);
  if (!o) { CM.sel = null; return renderProps(); }
  renderOpProps(box, o);
}
function renderModelProps(box) {
  const g = CM.geo, d = CM.doc, pl = d.placement || {};
  box.innerHTML = `<div class="row"><label class="cm-f">Part<select data-k="name">${$("#cm-source").innerHTML}</select></label></div>` +
    (g ? `<div class="hint">${g.face_keys.length} faces, ${fmt(g.volume_mm3 / 1000, 4)} cm^3, ${g.bbox.slice(3).map((v, i) => fmt(v - g.bbox[i], 5)).join(" x ")} mm (X ${fmt(g.bbox[0])}..${fmt(g.bbox[3])}, Y ${fmt(g.bbox[1])}..${fmt(g.bbox[4])}, Z ${fmt(g.bbox[2])}..${fmt(g.bbox[5])}, job coordinates)</div>` : "") +
    `<div class="row"><strong>Placement</strong> <span class="hint">${esc(placementText(pl))}; ${(pl.constraints || []).length} constraint(s)</span><button type="button" id="cm-place-edit" class="small">Edit</button></div>`;
  box.querySelector("select").value = (d.source || {}).name || "";
  box.querySelector("select").onchange = e => { d.source = { type: "part", name: e.target.value }; $("#cm-source").value = e.target.value; changed(false); loadGeometry(); };
  $("#cm-place-edit").onclick = openPlacement;
}
function renderOpsProps(box) {
  const ops = CM.doc.operations || [];
  const t = CM.res ? CM.res.operations.reduce((s, o) => s + (o.time_s || 0), 0) : null;
  box.innerHTML = `<div class="hint">${ops.length} operation(s), run in the order of the list${t !== null ? `; ${fmt(t / 60, 3)} min after the last run` : ""}. The toolbar adds an operation at the end of the list; double-click an operation to edit it.</div>`;
}
function renderPcProps(box, id) {
  const c = ((CM.doc.placement || {}).constraints || []).find(x => x.id === id);
  if (!c) { CM.sel = "part"; return renderProps(); }
  const bad = CM.placeRes && (CM.placeRes.unsatisfied || {})[id];
  box.innerHTML = `<div class="row"><strong>${esc(pcLabel(c))}</strong><button type="button" id="cm-place-edit" class="small">Edit</button></div>` + (bad ? `<div class="cm-err">${esc(bad)}</div>` : "");
  $("#cm-place-edit").onclick = openPlacement;
}
function renderStockProps(box) {
  const d = CM.doc, st = d.stock || (d.stock = { kind: "offsets" }), og = d.origin || (d.origin = { xy: "stock_min", z: "stock_top" });
  let h = `<div class="row">${selField("Stock", "kind", st.kind || "offsets", [["offsets", "Part bounding box with offsets"], ["box", "Box (coordinates)"], ["part_filled", "Part with the undercuts filled"]], "Part with the undercuts filled: the stock an earlier program with an end mill leaves")}${materialField(st.material)}</div>`;
  if (st.kind === "box") h += `<div class="row">${numField("X min", "xmin", st.xmin)}${numField("X max", "xmax", st.xmax)}${numField("Y min", "ymin", st.ymin)}${numField("Y max", "ymax", st.ymax)}${numField("Z min", "zmin", st.zmin)}${numField("Z max", "zmax", st.zmax)}</div><div class="hint">mm, part coordinates; empty: the part bounding box</div>`;
  else if (st.kind !== "part_filled") h += `<div class="row">${numField("X neg", "xneg", st.xneg)}${numField("X pos", "xpos", st.xpos)}${numField("Y neg", "yneg", st.yneg)}${numField("Y pos", "ypos", st.ypos)}${numField("Z neg", "zneg", st.zneg)}${numField("Z pos", "zpos", st.zpos)}</div><div class="hint">mm beyond the part bounding box</div>`;
  h += `<div class="row">${selField("Machine zero X Y", "oxy", og.xy, ORIGIN_XY, "Work offset in X and Y")}${selField("Machine zero Z", "oz", og.z, ORIGIN_Z)}` +
    `<button type="button" id="cm-zero-pick" class="small${CM.zeroPick ? " primary" : ""}" title="Click a vertex of the part in the view: the machine zero X, Y and Z at that vertex (Esc: cancel)">Pick vertex</button></div>` +
    (og.point ? `<div class="hint">Picked vertex X ${fmt(og.point[0])} Y ${fmt(og.point[1])} Z ${fmt(og.point[2])} mm (job coordinates)</div>` : "") + `<div class="hint" id="cm-setup-hint"></div>`;
  box.innerHTML = h;
  setupHint();
  const again = () => { changed(); loadSetup().then(() => { setupHint(); draw(); renderTree(); }); };
  bindFields(box, st, k => { if (k === "kind") renderStockProps(box); if (k === "material") { changed(false); renderTree(); return; } again(); }, true);
  box.querySelectorAll("select[data-k=oxy], select[data-k=oz]").forEach(sel => sel.onchange = () => {
    og[sel.dataset.k === "oxy" ? "xy" : "z"] = sel.value;
    if (sel.value === "point" && !og.point) { startZeroPick(); return; }
    again();
  });
  $("#cm-zero-pick").onclick = startZeroPick;
}
function setupHint() {
  const su = CM.setup, el = $("#cm-setup-hint");
  if (!el) return;
  el.textContent = su && su.stock_bbox ? `Stock ${fmt(su.stock_bbox[3] - su.stock_bbox[0], 5)} x ${fmt(su.stock_bbox[4] - su.stock_bbox[1], 5)} x ${fmt(su.stock_bbox[5] - su.stock_bbox[2], 5)} mm; machine zero at part X ${fmt(su.origin[0])} Y ${fmt(su.origin[1])} Z ${fmt(su.origin[2])}; clearance Z ${fmt(su.clearance_z - su.origin[2])} mm (machine)` : "";
}
function renderSetupProps(box) {
  const su = CM.doc.setup || (CM.doc.setup = Object.assign({}, (CM.meta && CM.meta.setup) || {}));
  box.innerHTML = `<div class="hint">Defaults of the operations (an operation's own value, when set, is used instead).</div>
    <div class="row">${numField("Clearance height offset (mm)", "clearance_offset", su.clearance_offset, "Above the start depth: rapid moves between operations")}${numField("Safe height offset (mm)", "safe_offset", su.safe_offset, "Above the start depth: rapid moves inside an operation")}</div>
    <div class="row">${numField("Step down (mm)", "step_down", su.step_down)}${numField("Finish depth (mm)", "finish_depth", su.finish_depth, "Height of the last level; 0: none")}</div>
    <div class="row">${numField("Horizontal rapid (mm/min)", "hrapid", su.hrapid, "For the cycle time")}${numField("Vertical rapid (mm/min)", "vrapid", su.vrapid)}${selField("Coolant", "coolant", su.coolant || "none", [["none", "None"], ["flood", "Flood (M08)"], ["mist", "Mist (M07)"]])}</div>
    <div class="pt-sec">Machine</div><div class="hint">Spindle limits for the feeds and speeds calculator and the sanity check.</div>
    <div class="row">${numField("Spindle min (rpm)", "rpm_min", su.rpm_min)}${numField("Spindle max (rpm)", "rpm_max", su.rpm_max)}${numField("Rated speed (rpm)", "rpm_rated", su.rpm_rated, "The spindle gives its rated power from this speed up; below it the torque is constant (power proportional to the speed)")}${numField("Spindle power (kW)", "power_kw", su.power_kw)}${numField("Max feed (mm/min)", "feed_max", su.feed_max)}</div>`;
  bindFields(box, su, () => changed(), false);
}
function renderToolsProps(box) {
  const d = CM.doc;
  box.innerHTML = `<div class="hint">A tool controller: a tool bit of the library with its feeds, spindle speed and tool number. Operations refer to a controller.</div>
    <div class="row"><label class="cm-f">Add from bit<select id="cm-tc-bit">${CM.bits.map(b => `<option value="${esc(b.id)}">${esc(b.id)} ${esc(b.name || "")}</option>`).join("")}</select></label><button type="button" id="cm-tc-add" class="small">Add controller</button>
    <button type="button" id="cm-fs-all" class="small" title="Feed, plunge feed and spindle speed of every controller from the feeds and speeds calculator (the material of the stock, the ae and ap of each controller)">Feeds and speeds for all</button></div>
    ${(d.tools || []).length ? `<table class="fa-tbl"><tr><th>Id</th><th>Name</th><th>Bit</th><th>T</th><th>Feed</th><th>Plunge</th><th>rpm</th></tr>${d.tools.map(t => `<tr><td>${esc(t.id)}</td><td>${esc(t.name || "")}</td><td>${esc(t.bit)}</td><td>${esc(t.number)}</td><td>${fmt(t.hfeed)}</td><td>${fmt(t.vfeed)}</td><td>${fmt(t.rpm)}</td></tr>`).join("")}</table>` : ""}`;
  $("#cm-tc-add").onclick = () => { addTc($("#cm-tc-bit").value); };
  $("#cm-fs-all").onclick = applyFeedsAll;
}
/** A tool controller for a bit (the defaults of the bit); returns its id. */
function addTc(bitId) {
  const b = bitOf(bitId);
  if (!b) return null;
  const tcs = CM.doc.tools || (CM.doc.tools = []);
  let n = tcs.length + 1;
  while (tcs.some(t => t.id === "TC" + n || t.number === n)) n++;
  const tc = { id: "TC" + n, name: b.name || b.id, bit: b.id, number: n, hfeed: b.feed || 500, vfeed: b.plunge || 150, rpm: b.rpm || 10000, dir: "CW" };
  tcs.push(tc);
  changed(); CM.sel = "tc:" + tc.id; renderAll();
  return tc.id;
}
function renderTcProps(box, id) {
  const tc = tcOf(id);
  if (!tc) { CM.sel = "tools"; return renderProps(); }
  const b = bitOf(tc.bit);
  box.innerHTML = `<div class="row">${numField("Id", "id", tc.id, "", "cm-name")}${numField("Name", "name", tc.name, "", "cm-name")}</div>
    <div class="row">${selField("Tool bit", "bit", tc.bit, CM.bits.map(x => [x.id, `${x.id} ${x.name || ""} (${fmt(x.d)} mm)`]))}${numField("Tool number", "number", tc.number, "T number of the G-code")}</div>
    <div class="row">${numField("Feed (mm/min)", "hfeed", tc.hfeed)}${numField("Plunge feed (mm/min)", "vfeed", tc.vfeed)}${numField("Spindle (rpm)", "rpm", tc.rpm)}${selField("Direction", "dir", tc.dir || "CW", [["CW", "CW (M03)"], ["CCW", "CCW (M04)"]])}</div>
    ${b ? `<div class="hint">${esc((CM.meta && CM.meta.shapes && CM.meta.shapes[b.shape]) || b.shape)} D ${fmt(b.d)} mm${b.angle ? `, ${fmt(b.angle)} deg` : ""}, cutting height ${fmt(b.height)} mm, neck ${fmt(b.neck)} mm, shank ${fmt(b.shank)} mm, ${b.flutes || "-"} flutes, ${b.tool_material === "hss" ? "HSS" : "carbide"}</div>` : `<div class="cm-err">The bit ${esc(tc.bit)} is not in the library.</div>`}
    ${b ? feedsSection(tc, b) : ""}`;
  bindFields(box, tc, k => {
    if (k === "id") { const nn = String(tc.id || "").trim() || id; tc.id = nn; for (const o of CM.doc.operations || []) if (o.tc === id) o.tc = nn; CM.sel = "tc:" + nn; }
    if (k === "bit" && b && (tc.name === b.name || !tc.name)) { const nb = bitOf(tc.bit); if (nb) tc.name = nb.name || nb.id; }
    changed(); renderAll();
  }, false);
  if (b) bindFeedsSection(box, tc, b);
}

// ------------------------------------------------------------------ feeds and speeds

function materialName(id) { const m = ((CM.meta && CM.meta.materials) || []).find(x => x.id === id); return m ? m.name : ""; }
/** Workpiece material select (grouped) for the Stock properties. */
function materialField(cur) {
  const groups = {};
  for (const m of (CM.meta && CM.meta.materials) || []) (groups[m.group] = groups[m.group] || []).push(m);
  return `<label class="cm-f" title="Workpiece material for the feeds and speeds calculator">Material<select data-k="material"><option value="">(not set)</option>` +
    Object.keys(groups).map(g => `<optgroup label="${esc(g)}">${groups[g].map(m => `<option value="${esc(m.id)}"${m.id === cur ? " selected" : ""}>${esc(m.name)}</option>`).join("")}</optgroup>`).join("") + `</select></label>`;
}
/** Feeds and speeds of a tool controller's bit (server feeds.calc). */
async function calcFeeds(tcid, ae, ap) {
  const r = await postJSON("/api/cam/feeds", { cam: CM.doc, tc: tcid, ae, ap });
  return r.json();
}
function feedsResultHtml(r) {
  const lim = { rpm_max: "spindle max", feed_max: "max feed", power: "spindle power" };
  return `<table class="fa-tbl cm-fs"><tr><td>Spindle</td><td>${fmt(r.rpm, 5)} rpm</td><td>Cutting speed</td><td>${fmt(r.vc, 4)} m/min at D ${fmt(r.deff, 4)} mm</td></tr>
    <tr><td>Feed</td><td>${fmt(r.feed, 5)} mm/min</td><td>Plunge feed</td><td>${fmt(r.plunge, 5)} mm/min</td></tr>
    <tr><td>Chip load</td><td>${fmt(r.fz_adj, 3)} mm/tooth</td><td>Table / thinning</td><td>${fmt(r.fz, 3)} mm/tooth × ${fmt(r.rctf, 3)}</td></tr>
    <tr><td>Chip thickness</td><td>${fmt(r.hm, 3)} mm</td><td>Removal rate</td><td>${fmt(r.mrr, 4)} cm^3/min</td></tr>
    <tr><td>Power</td><td>${fmt(r.power_kw, 3)} kW</td><td>Available</td><td>${fmt(r.power_avail_kw, 3)} kW, torque ${fmt(r.torque_nm, 3)} N·m</td></tr></table>` +
    (r.limited.length ? `<div class="hint">Limited by: ${r.limited.map(x => lim[x] || x).join(", ")}</div>` : "") +
    r.warnings.map(w => `<div class="cm-warn">${esc(w)}</div>`).join("");
}
function feedsSection(tc, b) {
  const fs = tc.fs || {}, su = CM.doc.setup || {}, mat = (CM.doc.stock || {}).material;
  return `<div class="pt-sec">Feeds and speeds</div>` +
    (mat ? `<div class="hint">Material ${esc(materialName(mat))} (Stock)</div>` : `<div class="cm-warn">No workpiece material: set Material in the Stock properties.</div>`) +
    `<div class="row"><label class="cm-f" title="Width of cut (radial engagement); empty: D (slot)">ae (mm)<input type="text" class="numf" data-fs="ae" value="${fs.ae == null ? "" : fmt(fs.ae, 6)}" placeholder="${fmt(b.d, 4)}"></label>` +
    `<label class="cm-f" title="Depth of cut (axial engagement); empty: the step down of the setup sheet${b.shape === "drill" ? "; not used for a drill" : ""}">ap (mm)<input type="text" class="numf" data-fs="ap" value="${fs.ap == null ? "" : fmt(fs.ap, 6)}" placeholder="${fmt(su.step_down, 4)}"></label>` +
    `<button type="button" class="small primary" id="cm-fs-apply" title="Feed, plunge feed and spindle speed of the controller from the calculation"${mat ? "" : " disabled"}>Apply</button></div><div id="cm-fs-res"></div>`;
}
function bindFeedsSection(box, tc, b) {
  const out = box.querySelector("#cm-fs-res");
  let last = null;
  const run = async () => {
    if (!(CM.doc.stock || {}).material) return;
    const fs = tc.fs || {};
    try {
      last = await calcFeeds(tc.id, fs.ae, fs.ap == null ? (CM.doc.setup || {}).step_down : fs.ap);
      if (last.error) throw new Error(last.error);
      out.innerHTML = feedsResultHtml(last);
    } catch (e) { last = null; out.innerHTML = `<div class="cm-err">${esc(e.message || e)}</div>`; }
  };
  box.querySelectorAll("[data-fs]").forEach(inp => inp.onchange = () => {
    const v = inp.value.trim() === "" ? null : num(inp.value);
    if (v !== null && !(v > 0)) { inp.value = ""; return; }
    tc.fs = Object.assign({}, tc.fs || {}, { [inp.dataset.fs]: v });
    changed(false); run();
  });
  box.querySelector("#cm-fs-apply").onclick = async () => {
    if (!last) await run();
    if (!last) return;
    tc.rpm = last.rpm; tc.hfeed = last.feed; tc.vfeed = last.plunge;
    changed(); renderAll();
    status(`${tc.id}: ${fmt(last.rpm, 5)} rpm, feed ${fmt(last.feed, 5)} mm/min, plunge ${fmt(last.plunge, 5)} mm/min`);
  };
  run();
}
/** All tool controllers from the calculator with their own ae and ap. */
async function applyFeedsAll() {
  if (!(CM.doc.stock || {}).material) { status("Set the material of the stock first", true); return; }
  const done = [];
  for (const tc of CM.doc.tools || []) {
    const fs = tc.fs || {};
    try {
      const r = await calcFeeds(tc.id, fs.ae, fs.ap == null ? (CM.doc.setup || {}).step_down : fs.ap);
      if (r.error) throw new Error(r.error);
      tc.rpm = r.rpm; tc.hfeed = r.feed; tc.vfeed = r.plunge;
      done.push(tc.id);
    } catch (e) { status(`${tc.id}: ${e.message || e}`, true); }
  }
  changed(); renderAll();
  if (done.length) status(`Feeds and speeds applied to ${done.join(", ")}`);
}
/** Width and depth of cut of an operation for the calculator: ae the step over (Adaptive, Face, 3D Surface,
 *  Waterline, 3D Pocket, Helix) or the step of the Undercut passes, else D (a pocket and a profile start with a full
 *  slot); ap the step down of the operation (resolved after a preview), the engraving depth, or the flank of a
 *  dovetail. */
function opEngagement(o, b) {
  const D = +b.d || 6, r = recOf(o.id), su = CM.doc.setup || {};
  let ae = D;
  if (["adaptive", "face", "surface", "waterline", "pocket3d", "helix"].includes(o.type) && o.stepover_pct > 0) ae = D * o.stepover_pct / 100;
  if (o.type === "undercut") ae = +o.stepover || 1;
  let ap = o.step_down != null ? o.step_down : r && r.heights && r.heights.step ? r.heights.step : su.step_down;
  if (o.type === "engrave") ap = o.depth || ap;
  if (o.type === "deburr") ap = (+o.width || 1) + (+o.extra_depth || 0);
  if (o.type === "undercut") ap = +b.height || ap;
  return { ae: Math.min(ae, D), ap };
}
async function applyFeedsOp(o) {
  const ot = OPS[o.type] || {}, tc = tcOf(o.tc), b = tc && bitOf(tc.bit);
  if (!b || ot.supplemental || ot.derived) { status("The operation has no tool controller", true); return; }
  if (!(CM.doc.stock || {}).material) { status("Set the material of the stock first", true); return; }
  const { ae, ap } = opEngagement(o, b);
  try {
    const r = await calcFeeds(tc.id, ae, ap);
    if (r.error) throw new Error(r.error);
    o.feed = r.feed; o.plunge = r.plunge; o.rpm = r.rpm;
    CM.fsOp = { id: o.id, r };
    changed(); renderCommand(true); renderProps();
    status(`${o.name}: ae ${fmt(r.ae, 4)} mm, ap ${fmt(r.ap, 4)} mm: ${fmt(r.rpm, 5)} rpm, feed ${fmt(r.feed, 5)} mm/min, plunge ${fmt(r.plunge, 5)} mm/min`);
  } catch (e) { showErr(e); }
}
function renderJobProps(box) {
  const d = CM.doc, out = d.output || (d.output = { folder: "", name: "" });
  box.innerHTML = `<div class="row"><span class="hint">Job ${esc(d.name || "")} (File ▾ saves and renames it)</span></div>
    <div class="row">${selField("Post-processor", "post", d.post || "estlcam", CM.posts.map(p => [p.id, p.name]))}</div>
    <div class="row">${numField("File name", "name", out.name, "Empty: <job name>.nc", "cm-name")}</div>
    <div class="row">${numField("Folder", "folder", out.folder, "Empty: the cam folder of the project", "cm-path")}</div>
    <div class="row"><button type="button" id="cm-out-post" class="primary">Post process</button><button type="button" id="cm-out-dl">Download</button></div>`;
  bindFields(box, out, () => { changed(false); renderTree(); }, false);
  box.querySelector("select[data-k=post]").onchange = e => { d.post = e.target.value; changed(false); renderPost(); renderTree(); };
  $("#cm-out-post").onclick = () => writeGcode(false);
  $("#cm-out-dl").onclick = () => writeGcode(true);
}
/** Properties of an operation: its summary and the results of the last run. */
function renderOpProps(box, o) {
  const r = recOf(o.id), ot = OPS[o.type] || {};
  let h = `<div class="row"><strong>${esc(o.name)}</strong> <span class="hint">${esc(opLabel(o))}</span><button type="button" id="cm-edit" class="small">Edit</button></div>`;
  if (!ot.supplemental) {
    const tc = tcOf(o.tc), b = tc && bitOf(tc.bit);
    h += `<div class="hint">${tc ? `${esc(tc.id)} ${esc(tc.name || "")}${b ? `, D ${fmt(b.d)} mm` : ""}` : "no tool controller"}${(o.faces || []).length ? `; ${o.faces.length} face(s)` : ""}${(o.edges || []).length ? `; ${o.edges.length} edge(s)` : ""}${(o.dressups || []).length ? `; dressups: ${o.dressups.map(x => (DRESSUPS[x.type] || {}).label || x.type).join(", ")}` : ""}</div>`;
  }
  if (r) {
    h += `<div class="fa-props">` + (r.ok ? `<span class="cm-ok">ok</span>` : `<span class="cm-err">error</span>`);
    for (const e of r.errors || []) h += `<div class="cm-err">${esc(e)}</div>`;
    for (const m of r.messages || []) h += `<div class="hint">${esc(m)}</div>`;
    if (r.heights) h += `<div class="hint">clearance Z ${fmt(r.heights.clearance)}, safe Z ${fmt(r.heights.safe)}, start Z ${fmt(r.heights.start)}, final Z ${fmt(r.heights.final)} mm (part), step ${fmt(r.heights.step)} mm</div>`;
    if (r.ok && r.moves && r.moves.length && r.time_s != null)
      h += `<div class="hint">removed ${fmt(r.removed_mm3, 5)} mm^3${r.remaining_mm3 > 0.001 ? `, ${fmt(r.remaining_mm3, 4)} mm^3 left` : ""}${r.gouge_mm3 > 0.05 ? `, <span class="cm-err">gouge ${fmt(r.gouge_mm3, 4)} mm^3</span>` : ""}; cut ${fmt(r.cut_mm, 5)} mm, rapid ${fmt(r.rapid_mm, 5)} mm, ${fmt(r.time_s / 60, 3)} min; feed ${fmt(r.feed)} mm/min, plunge ${fmt(r.plunge)} mm/min, ${fmt(r.rpm)} rpm; ${r.moves.length} moves</div>`;
    if ((r.levels || []).length) h += `<table class="fa-tbl"><tr><th>Level</th><th>Z (mm)</th><th>Length (mm)</th><th>Removed (mm^3)</th></tr>` + r.levels.map((l, i) => `<tr><td>${i + 1}</td><td>${fmt(l.z)}</td><td>${fmt(l.length_mm, 5)}</td><td>${fmt(l.removed_mm3, 5)}</td></tr>`).join("") + `</table>`;
    h += `</div>`;
  } else h += `<div class="hint">Not computed yet.</div>`;
  box.innerHTML = h;
  $("#cm-edit").onclick = () => openCommand(o.id);
}

// ------------------------------------------------------------------ adding operations and dressups

function defaults(fields) {
  const o = {};
  for (const f of fields || []) if (f.def !== undefined) o[f.k] = f.def;
  return o;
}
/** The tool controller for a type: the first whose bit has one of the type's shapes, made from the library when
 *  the job has none. */
function tcFor(ot) {
  const tcs = CM.doc.tools || [];
  const ok = tcs.find(t => { const b = bitOf(t.bit); return b && ot.tools.includes(b.shape); });
  if (ok) return ok.id;
  const b = CM.bits.find(x => ot.tools.includes(x.shape));
  if (b) { const id = addTc(b.id); return id; }
  return tcs.length ? tcs[0].id : "";
}
function addOp(type) {
  if (!hasSource()) { status("Choose a part first", true); return; }
  const ot = OPS[type];
  if (!ot) return;
  const n = (CM.doc.operations || []).filter(o => o.type === type).length + 1;
  const op = Object.assign({ id: nid("op"), name: ot.label + (n > 1 ? " " + n : ""), type, active: true, comment: "", dressups: [] }, defaults(ot.fields));
  if (type === "fixture") { op.shift = [0, 0, 0]; delete op.sx; delete op.sy; delete op.sz; }
  if (!ot.supplemental && !ot.derived) {
    op.tc = tcFor(ot);
    for (const k of ["clearance_height", "safe_height", "start_depth", "final_depth", "step_down", "finish_depth"]) op[k] = null;
    op.feed = null; op.plunge = null; op.rpm = null;
    if (ot.base) { if (ot.base.faces) op.faces = []; if (ot.base.edges) op.edges = []; if (ot.base.points) op.points = []; }
    if (ot.text) op.text = defaults(TEXT_FIELDS);
    if (ot.sketch) op.sketch = null;
    if (type === "drilling") op.through = null;
  }
  if (ot.derived) {
    const cands = (CM.doc.operations || []).filter(o => !(OPS[o.type] || {}).supplemental && !(OPS[o.type] || {}).derived);
    op.of = CM.sel && opOf(CM.sel) && cands.some(o => o.id === CM.sel) ? CM.sel : (cands.length ? cands[cands.length - 1].id : "");
  }
  (CM.doc.operations = CM.doc.operations || []).push(op);
  CM.sel = op.id;
  changed(false);
  renderAll();
  openCommand(op.id, undefined, true);
}
function addDressup(type) {
  const o = CM.cmd ? opOf(CM.cmd.id) : (CM.sel && opOf(CM.sel));
  if (!o) { status("Select an operation first", true); return; }
  const ot = OPS[o.type] || {};
  if (ot.supplemental || ot.derived) { status("A dressup applies to a cutting operation", true); return; }
  if (type === "tag" && (o.dressups || []).some(x => x.type === "tag")) { status("The operation has a Tag dressup", true); return; }
  const dr = Object.assign({ type }, defaults((DRESSUPS[type] || {}).fields));
  if (type === "boundary" && CM.setup && CM.setup.stock_bbox) { const b = CM.setup.stock_bbox; Object.assign(dr, { xmin: b[0], xmax: b[3], ymin: b[1], ymax: b[4] }); }
  (o.dressups = o.dressups || []).push(dr);
  changed(false);
  renderAll();
  openCommand(o.id, o.dressups.length - 1, true);
}

// ------------------------------------------------------------------ machine zero at a vertex

/** The vertices of the part: the end points of its edges (job coordinates). */
function geoVertices() {
  const g = CM.geo;
  if (!g) return [];
  if (g._verts) return g._verts;
  const out = [], seen = new Set();
  for (const pl of g.edges || []) for (const p of pl.length ? [pl[0], pl[pl.length - 1]] : []) {
    const k = p.map(v => Math.round(v * 1e4)).join(",");
    if (!seen.has(k)) { seen.add(k); out.push(p); }
  }
  return (g._verts = out);
}
/** The vertex nearest to the cursor within 12 px, or null. */
function vertexAt(e) {
  const t = CM.three, r = t.renderer.domElement.getBoundingClientRect();
  t.camera.updateMatrixWorld(true);
  let best = null, bd = 12;
  for (const p of geoVertices()) {
    const q = new THREE.Vector3(p[0], p[1], p[2]).project(t.camera);
    const d = Math.hypot(r.left + (q.x + 1) / 2 * r.width - e.clientX, r.top + (1 - q.y) / 2 * r.height - e.clientY);
    if (d < bd) { bd = d; best = p; }
  }
  return best;
}
function startZeroPick() {
  if (!CM.geo) { status("Choose a part first", true); return; }
  CM.zeroPick = true;
  $("#cm-zero").classList.add("active");
  status("Click a vertex of the part: the machine zero (Esc: cancel)");
  if (CM.sel === "stock") renderProps();
}
function endZeroPick() {
  CM.zeroPick = false;
  $("#cm-zero").classList.remove("active");
  clearHover(); render3();
  if (CM.sel === "stock") renderProps();
}
function hoverZero(e) {
  const t = CM.three;
  clearHover();
  const p = vertexAt(e);
  if (p) {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(p, 3));
    const m = new THREE.Points(g, new THREE.PointsMaterial({ color: COLORS.sel, size: 11, sizeAttenuation: false, depthTest: false }));
    m.renderOrder = 12;
    t.hover = m; t.scene.add(m);
  }
  t.renderer.domElement.style.cursor = p ? "crosshair" : "";
  render3();
}
function clickZero(e) {
  const p = vertexAt(e);
  if (!p) { status("No vertex under the cursor", true); return; }
  const og = CM.doc.origin || (CM.doc.origin = {});
  og.xy = "point"; og.z = "point"; og.point = p.map(v => Math.round(v * 1e4) / 1e4 + 0);
  endZeroPick();
  CM.sel = "stock";
  changed();
  loadSetup().then(() => { renderTree(); renderProps(); setupHint(); draw(); });
  status(`Machine zero at X ${fmt(og.point[0])} Y ${fmt(og.point[1])} Z ${fmt(og.point[2])} mm`);
}

// ------------------------------------------------------------------ model placement

const PC_TYPES = [["coincident", "Coincident"], ["distance", "Distance"], ["parallel", "Parallel"], ["angle", "Angle"], ["concentric", "Concentric"]];
const PC_HELP = { coincident: "A planar face in a datum plane, or a cylinder axis on a datum axis", distance: "A planar face parallel to a datum plane at a distance",
                  parallel: "A planar face parallel to a datum plane, or a cylinder axis parallel to a datum axis", angle: "A planar face at an angle to a datum plane",
                  concentric: "A cylindrical face on a datum axis" };
const DATUM_OPTS = [["XY", "XY plane (table)"], ["XZ", "XZ plane"], ["YZ", "YZ plane"], ["X", "X axis"], ["Y", "Y axis"], ["Z", "Z axis"]];
/** Rotation matrix Rz Ry Rx of rotations (deg) about the fixed X, Y, Z axes (assembly convention). */
function rotMatrix(rot) {
  const [ax, ay, az] = (rot || [0, 0, 0]).map(v => (v || 0) * Math.PI / 180);
  const cx = Math.cos(ax), sx = Math.sin(ax), cy = Math.cos(ay), sy = Math.sin(ay), cz = Math.cos(az), sz = Math.sin(az);
  return [[cz * cy, cz * sy * sx - sz * cx, cz * sy * cx + sz * sx], [sz * cy, sz * sy * sx + cz * cx, sz * sy * cx - cz * sx], [-sy, cy * sx, cy * cx]];
}
const mv = (R, v) => [0, 1, 2].map(i => R[i][0] * v[0] + R[i][1] * v[1] + R[i][2] * v[2]);
const mtv = (R, v) => [0, 1, 2].map(i => R[0][i] * v[0] + R[1][i] * v[1] + R[2][i] * v[2]);
/** The picked faces, edges and points of the operations moved with the part from one placement to another. */
function remapPicks(from, to) {
  const Ro = rotMatrix(from.rot), Rn = rotMatrix(to.rot), po = from.pos || [0, 0, 0], pn = to.pos || [0, 0, 0];
  const pt = p => { const l = mtv(Ro, [p[0] - po[0], p[1] - po[1], p[2] - po[2]]); const q = mv(Rn, l); return [q[0] + pn[0], q[1] + pn[1], q[2] + pn[2]].map(v => Math.round(v * 1e6) / 1e6); };
  const dir = n => mv(Rn, mtv(Ro, n)).map(v => Math.round(v * 1e9) / 1e9);
  for (const o of CM.doc.operations || []) {
    for (const f of o.faces || []) { if (f.c) f.c = pt(f.c); if (f.n) f.n = dir(f.n); }
    for (const e of o.edges || []) if (e.mid) e.mid = pt(e.mid);
    if (o.points) o.points = o.points.map(p => pt([p[0], p[1], 0]).slice(0, 2));
  }
  const og = CM.doc.origin;
  if (og && og.point) og.point = pt(og.point);
}
function placementOf() {
  const pl = CM.doc.placement || (CM.doc.placement = { pos: [0, 0, 0], rot: [0, 0, 0], constraints: [], next: 1 });
  pl.pos = pl.pos || [0, 0, 0]; pl.rot = pl.rot || [0, 0, 0]; pl.constraints = pl.constraints || []; pl.next = pl.next || pl.constraints.length + 1;
  return pl;
}
/** A new position and rotation of the part: the picks of the operations follow, the geometry and the stock are loaded again. */
function setPlacement(pos, rot) {
  const pl = placementOf();
  const from = { pos: pl.pos.slice(), rot: pl.rot.slice() };
  const same = from.pos.every((v, i) => Math.abs(v - pos[i]) < 1e-9) && from.rot.every((v, i) => Math.abs(v - rot[i]) < 1e-9);
  pl.pos = pos.slice(); pl.rot = rot.slice();
  if (same) return false;
  remapPicks(from, pl);
  changed(false);
  if (CM.three) CM.three.zoomed = false;
  loadGeometry();
  return true;
}
/** Solve of the placement constraints on the server from the current placement. */
async function solvePlacement() {
  const pl = placementOf();
  if (!pl.constraints.some(c => !c.suppressed)) { CM.placeRes = null; renderPlacementAll(); return; }
  const seq = (CM.placeSeq = (CM.placeSeq || 0) + 1);
  try {
    const r = await (await postJSON("/api/cam/placement", { cam: CM.doc })).json();
    if (seq !== CM.placeSeq) return;
    CM.placeRes = r;
    pl.constraints = r.constraints;
    if (!setPlacement(r.pos, r.rot)) changed(false);
  } catch (e) { showErr(e); }
  renderPlacementAll();
}
/** Tree, properties, the placement window (after the event that called it: a change event fires during a blur) and the selection. */
function renderPlacementAll() { renderTree(); renderProps(); drawSelection(); setTimeout(() => { if (CM.cmd && CM.cmd.place) renderCommand(true); }, 0); }
function openPlacement() {
  if (!hasSource()) { status("Choose a part first", true); return; }
  if (CM.cmd && !CM.cmd.place) closeCommand(true);
  if (!CM.cmd) CM.cmd = { place: true, id: null, pick: null, snapshot: JSON.stringify(placementOf()), snapOps: JSON.stringify(CM.doc.operations || []) };
  CM.sel = "model";
  renderTree(); renderProps(); renderCommand(true); draw();
}
function closePlacement(keep) {
  const c = CM.cmd;
  if (!keep) {
    const old = JSON.parse(c.snapshot), cur = placementOf();
    CM.doc.operations = JSON.parse(c.snapOps);
    CM.doc.placement = old;
    const moved = old.pos.some((v, i) => Math.abs(v - cur.pos[i]) > 1e-9) || old.rot.some((v, i) => Math.abs(v - cur.rot[i]) > 1e-9);
    changed(false);
    if (moved) { if (CM.three) CM.three.zoomed = false; loadGeometry(); }
    CM.placeRes = null;
  }
  CM.cmd = null;
  $("#cm-cmdwin").hidden = true;
  clearHover();
  renderTree(); renderProps(); draw();
}
function deleteConstraint(id) {
  const pl = placementOf();
  pl.constraints = pl.constraints.filter(c => c.id !== id);
  if (CM.sel === "pc:" + id) CM.sel = "part";
  changed(false);
  solvePlacement();
}
/** A face of the part clicked while a constraint type is chosen: the constraint with the datum and Flip that keep the
 *  part where it is (the server suggests them), then the solve. */
async function placePick(fi) {
  const c = CM.cmd, type = c.pick;
  try {
    const sg = await (await postJSON("/api/cam/placement", { cam: CM.doc, suggest: { face: fi, type } })).json();
    const pl = placementOf();
    const pc = { id: "pc" + (pl.next++), type, face: fi, datum: sg.datum, flip: sg.flip, value: sg.value, suppressed: false };
    pl.constraints.push(pc);
    c.pick = null;
    c.last = pc.id;
    status(`${pcLabel(pc)} added`);
    await solvePlacement();
  } catch (e) { showErr(e); }
}
function placementHtml(c) {
  const pl = placementOf(), res = CM.placeRes;
  let h = `<p class="hint">Constraints of faces of the part to the datum planes and axes of the job coordinate system (XY: the table plane, +Z: the spindle). Position and rotation without constraints, or the start of the solve.</p>`;
  h += `<div class="cw-pcbtns">${PC_TYPES.map(([t, l]) => `<button type="button" class="small ico-mini${c.pick === t ? " active" : ""}" data-pctype="${t}" title="${esc(PC_HELP[t])}: click the type, then a face of the part">${(window.treeIcon && window.treeIcon(PC_ICON[t], 18)) || ""}${l}</button>`).join("")}</div>`;
  if (c.pick) h += `<p class="hint cw-hint">${esc(PC_HELP[c.pick])}: click a face of the part (Esc: cancel)</p>`;
  if (pl.constraints.length) {
    h += `<table class="fa-tbl cw-pctbl"><tr><th>Constraint</th><th>Datum</th><th>Value</th><th>Flip</th><th>Off</th><th></th></tr>`;
    for (const k of pl.constraints) {
      const bad = res && (res.unsatisfied || {})[k.id];
      const val = k.type === "distance" || k.type === "angle" ? `<input type="text" class="numf" data-pcv="${esc(k.id)}" value="${fmt(k.value, 6)}" title="${k.type === "distance" ? "mm" : "deg"}">` : "";
      h += `<tr data-pc="${esc(k.id)}" class="${bad ? "bad" : ""}${k.id === c.last ? " last" : ""}"><td>${(PC_TYPES.find(x => x[0] === k.type) || [0, k.type])[1]} face ${(+k.face) + 1}</td>` +
        `<td><select data-pcd="${esc(k.id)}">${DATUM_OPTS.map(([v, l]) => `<option value="${v}"${v === k.datum ? " selected" : ""}>${v}</option>`).join("")}</select></td><td>${val}</td>` +
        `<td><input type="checkbox" data-pcf="${esc(k.id)}"${k.flip ? " checked" : ""} title="Turn the face the other way"></td><td><input type="checkbox" data-pcs="${esc(k.id)}"${k.suppressed ? " checked" : ""} title="Suppressed"></td>` +
        `<td><button type="button" class="small" data-pcdel="${esc(k.id)}" title="Delete">×</button></td></tr>` + (bad ? `<tr class="bad"><td colspan="6" class="cm-err">${esc(bad)}</td></tr>` : "");
    }
    h += `</table>`;
  }
  return h;
}
function positionHtml() {
  const pl = placementOf();
  return `<div class="cm-grid cm-grid3">${[0, 1, 2].map(i => `<label class="cm-f">${"XYZ"[i]} (mm)<input type="text" class="numf" data-ppos="${i}" value="${fmt(pl.pos[i], 7)}"></label>`).join("")}` +
    `${[0, 1, 2].map(i => `<label class="cm-f" title="Rotations about the fixed X, then Y, then Z axis about the part origin, before the translation">Rot ${"XYZ"[i]} (deg)<input type="text" class="numf" data-prot="${i}" value="${fmt(pl.rot[i], 7)}"></label>`).join("")}</div>
    <div class="buttons">${["X", "Y", "Z"].map((a, i) => `<button type="button" class="small" data-pturn="${i}" title="Turn the part 90 deg about the job ${a} axis through the centre of the part">${a} +90°</button>`).join("")}
    <button type="button" class="small" data-pdrop="1" title="Move the part so that its lowest point is on the XY plane and its bounding box starts at X 0, Y 0">Onto XY at 0, 0</button>
    <button type="button" class="small" data-preset="1" title="Position and rotation 0 (the constraints are kept)">Reset</button></div>
    ${pl.constraints.some(c => !c.suppressed) ? `<p class="hint">With active constraints a change here is the start of a new solve.</p>` : ""}`;
}
/** Turn about a job axis through the centre of the part bounding box. */
function turnPart(axis) {
  const pl = placementOf(), g = CM.geo;
  const ctr = g && g.bbox ? [0, 1, 2].map(i => (g.bbox[i] + g.bbox[i + 3]) / 2) : pl.pos.slice();
  const Rq = rotMatrix([axis === 0 ? 90 : 0, axis === 1 ? 90 : 0, axis === 2 ? 90 : 0]);
  const R = rotMatrix(pl.rot), Rn = [0, 1, 2].map(i => [0, 1, 2].map(j => Rq[i][0] * R[0][j] + Rq[i][1] * R[1][j] + Rq[i][2] * R[2][j]));
  // Euler angles of Rn in the convention of rotMatrix
  const sy = Math.max(-1, Math.min(1, -Rn[2][0])), ry = Math.asin(sy);
  let rx, rz;
  if (Math.abs(sy) < 0.999999) { rx = Math.atan2(Rn[2][1], Rn[2][2]); rz = Math.atan2(Rn[1][0], Rn[0][0]); } else { rx = Math.atan2(-Rn[1][2], Rn[1][1]); rz = 0; }
  const rot = [rx, ry, rz].map(v => Math.round(v * 180 / Math.PI * 1e6) / 1e6 + 0);
  const d = [pl.pos[0] - ctr[0], pl.pos[1] - ctr[1], pl.pos[2] - ctr[2]], q = mv(Rq, d);
  return { pos: [0, 1, 2].map(i => Math.round((ctr[i] + q[i]) * 1e6) / 1e6), rot };
}
function bindPlacement(box) {
  const c = CM.cmd, pl = placementOf();
  const find = id => pl.constraints.find(k => k.id === id);
  box.querySelectorAll("[data-pctype]").forEach(b => b.onclick = () => { c.pick = c.pick === b.dataset.pctype ? null : b.dataset.pctype; renderCommand(true); draw(); });
  box.querySelectorAll("[data-pcd]").forEach(sel => sel.onchange = () => { find(sel.dataset.pcd).datum = sel.value; changed(false); solvePlacement(); });
  box.querySelectorAll("[data-pcv]").forEach(inp => inp.onchange = () => { const v = num(inp.value); if (!isFinite(v)) { renderPlacementAll(); return; } find(inp.dataset.pcv).value = v; changed(false); solvePlacement(); });
  box.querySelectorAll("[data-pcf]").forEach(inp => inp.onchange = () => { find(inp.dataset.pcf).flip = inp.checked; changed(false); solvePlacement(); });
  box.querySelectorAll("[data-pcs]").forEach(inp => inp.onchange = () => { find(inp.dataset.pcs).suppressed = inp.checked; changed(false); solvePlacement(); });
  box.querySelectorAll("[data-pcdel]").forEach(b => b.onclick = () => deleteConstraint(b.dataset.pcdel));
  box.querySelectorAll("tr[data-pc]").forEach(tr => {
    tr.onmouseenter = () => { CM.chipHover = { pc: tr.dataset.pc }; drawSelection(); };
    tr.onmouseleave = () => { CM.chipHover = null; drawSelection(); };
  });
  const after = () => { if (pl.constraints.some(k => !k.suppressed)) solvePlacement(); else renderPlacementAll(); };
  box.querySelectorAll("[data-ppos], [data-prot]").forEach(inp => inp.onchange = () => {
    const v = num(inp.value);
    if (!isFinite(v)) { renderPlacementAll(); return; }
    const pos = pl.pos.slice(), rot = pl.rot.slice();
    if (inp.dataset.ppos !== undefined) pos[+inp.dataset.ppos] = v; else rot[+inp.dataset.prot] = v;
    setPlacement(pos, rot); after();
  });
  box.querySelectorAll("[data-pturn]").forEach(b => b.onclick = () => { const t = turnPart(+b.dataset.pturn); setPlacement(t.pos, t.rot); after(); });
  const dr = box.querySelector("[data-pdrop]");
  if (dr) dr.onclick = () => { const g = CM.geo; if (!g || !g.bbox) return; setPlacement([pl.pos[0] - g.bbox[0], pl.pos[1] - g.bbox[1], pl.pos[2] - g.bbox[2]], pl.rot); after(); };
  const rs = box.querySelector("[data-preset]");
  if (rs) rs.onclick = () => { setPlacement([0, 0, 0], [0, 0, 0]); after(); };
}
/** The datum planes XY, XZ, YZ (translucent squares) and the axes of the job coordinate system while the placement is edited. */
function drawDatums(box) {
  const t = CM.three, g = CM.geo;
  const s = g && g.bbox ? Math.max(g.bbox[3] - g.bbox[0], g.bbox[4] - g.bbox[1], g.bbox[5] - g.bbox[2], 10) * 0.6 : 50;
  const planes = [["XY", 0xf08c00, [[-s, -s, 0], [s, -s, 0], [s, s, 0], [-s, s, 0]]], ["XZ", 0x2b8a3e, [[-s, 0, -s], [s, 0, -s], [s, 0, s], [-s, 0, s]]], ["YZ", 0xe03131, [[0, -s, -s], [0, s, -s], [0, s, s], [0, -s, s]]]];
  for (const [, col, q] of planes) {
    const gm = track(new THREE.BufferGeometry());
    gm.setAttribute("position", new THREE.Float32BufferAttribute([...q[0], ...q[1], ...q[2], ...q[0], ...q[2], ...q[3]], 3));
    const m = new THREE.Mesh(gm, new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.08, side: THREE.DoubleSide, depthWrite: false }));
    t.group.add(m);
    const ge = track(new THREE.BufferGeometry());
    ge.setAttribute("position", new THREE.Float32BufferAttribute([...q[0], ...q[1], ...q[1], ...q[2], ...q[2], ...q[3], ...q[3], ...q[0]], 3));
    t.group.add(new THREE.LineSegments(ge, new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: 0.6 })));
    box.expandByObject(m);
  }
}

// ------------------------------------------------------------------ command window

/** Opens the command window for an operation (dr: the index of one of its dressups; isNew: Cancel removes it). */
function openCommand(id, dr, isNew) {
  const o = opOf(id);
  if (!o) return;
  if (CM.cmd && (CM.cmd.id !== id || CM.cmd.dr !== dr)) closeCommand(true);
  const ot = OPS[o.type] || {};
  CM.cmd = { id, dr, isNew: !!isNew, step: dr === undefined && ot.base ? 0 : dr === undefined && ot.depths ? 1 : 3, mode: null, snapshot: JSON.stringify(o) };
  CM.sel = dr === undefined ? id : `dr:${id}:${dr}`;
  renderTree(); renderProps(); renderCommand(true); draw();
  schedulePreview(0);
}
/** Closes the window; keep false: the operation as it was when the window opened (a new operation or dressup
 *  removed). */
function closeCommand(keep) {
  const c = CM.cmd;
  if (!c) return;
  if (c.place) { closePlacement(keep); return; }
  if (!keep) {
    const i = opIndex(c.id);
    if (i >= 0) {
      if (c.isNew && c.dr === undefined) { CM.doc.operations.splice(i, 1); if (CM.sel === c.id) CM.sel = null; }
      else if (c.isNew) { (CM.doc.operations[i].dressups || []).splice(c.dr, 1); CM.sel = c.id; }
      else CM.doc.operations[i] = JSON.parse(c.snapshot);
      changed(false);
    }
  }
  CM.cmd = null; CM.chipHover = null;
  $("#cm-cmdwin").hidden = true;
  clearHover();
  renderTree(); renderProps(); draw();
  schedulePreview(0);
}
function renderCommand(force) {
  const c = CM.cmd, box = $("#cm-cmdbody");
  if (!c) { $("#cm-cmdwin").hidden = true; return; }
  const ae = document.activeElement;
  if (!force && ae && box.contains(ae) && ae.matches("input, select, textarea")) return;
  if (c.place) {
    const res = CM.placeRes;
    let h = `<div class="cmd cw">` + section(0, true, true, "Constraints", placementHtml(c), `${placementOf().constraints.length}`) + section(1, true, true, "Position", positionHtml(), placementText(placementOf()));
    h += `<div class="cw-result">${((res && res.messages) || []).map(m => `<p class="hint err">${esc(m)}</p>`).join("")}</div>`;
    h += `<div class="cw-foot cmd-foot"><button type="button" id="cm-cmd-ok" class="primary">OK</button><button type="button" id="cm-cmd-cancel" title="The placement as it was when the window opened">Cancel</button></div></div>`;
    box.innerHTML = h;
    $("#cm-cmdwin-title").textContent = "Model placement";
    bindPlacement(box);
    box.querySelector("#cm-cmd-ok").onclick = () => closeCommand(true);
    box.querySelector("#cm-cmd-cancel").onclick = () => closeCommand(false);
    $("#cm-cmdwin").hidden = false;
    placeCmdWin();
    return;
  }
  const o = opOf(c.id);
  if (!o) { CM.cmd = null; $("#cm-cmdwin").hidden = true; return; }
  const ot = OPS[o.type] || {};
  const r = recOf(o.id);
  let h = `<div class="cmd cw">`;
  if (c.dr !== undefined) {
    const dr = (o.dressups || [])[c.dr];
    if (!dr) { closeCommand(true); return; }
    const dd = DRESSUPS[dr.type] || { fields: [] };
    h += `<div class="cw-name"><label>Dressup of<span>${esc(o.name)}</span></label></div>`;
    h += section(3, true, false, dd.label, fieldsHtml(dd.fields, dr), "");
    $("#cm-cmdwin-title").textContent = dd.label;
  } else {
    h += `<div class="cw-name"><label>Name<input type="text" id="cm-opname" value="${esc(o.name)}"></label></div>`;
    if (ot.base || ot.sketch || ot.text) h += section(0, c.step === 0, baseDone(o, ot), "Base geometry", baseHtml(o, ot, c), baseSummary(o));
    if (ot.depths) h += section(1, c.step === 1, true, "Depths", depthsHtml(o, r), "");
    if (ot.depths) h += section(2, c.step === 2, true, "Heights", heightsHtml(o, r), "");
    h += section(3, c.step === 3, true, "Operation", opHtml(o, ot), "");
    $("#cm-cmdwin-title").textContent = opLabel(o);
  }
  h += `<div class="cw-result">`;
  if (r) { for (const e of r.errors || []) h += `<p class="hint err">${esc(e)}</p>`; for (const m of (r.messages || []).slice(0, 4)) h += `<p class="hint">${esc(m)}</p>`; }
  else if (CM.previewTimer || CM.previewSeq) h += `<p class="hint">Computing…</p>`;
  h += `</div><div class="cw-foot cmd-foot"><button type="button" id="cm-cmd-ok" class="primary">OK</button><button type="button" id="cm-cmd-cancel" title="${c.isNew ? "Remove the new operation" : "The operation as it was when the window opened"}">Cancel</button></div></div>`;
  box.innerHTML = h;
  const nm = box.querySelector("#cm-opname");
  if (nm) nm.onchange = () => { o.name = nm.value.trim() || o.name; changed(false); renderTree(); };
  box.querySelectorAll(".cw-sec").forEach(sec => {
    const i = +sec.dataset.step;
    sec.querySelector(".cw-sec-head").onclick = () => { if (i !== c.step) { c.step = i; renderCommand(true); draw(); } };
    sec.addEventListener("focusin", () => { if (CM.cmd && i !== c.step) { c.step = i; box.querySelectorAll(".cw-sec").forEach(s => s.classList.toggle("active", +s.dataset.step === i)); draw(); } });
  });
  const target = c.dr !== undefined ? (o.dressups || [])[c.dr] : o;
  bindFields(box, target, k => {
    if (k === "through") target.through = target.through === "auto" ? null : target.through === "through";
    if (k === "of" || k === "kind" || k === "boundary" || k === "pattern" || k === "mode") renderCommand(true);
    changed(); renderTree();
  }, true);
  if (c.dr === undefined) bindBase(box, o, ot, c);
  // fields of nested objects: the text {text, size, ...} and the fixture shift
  box.querySelectorAll("[data-tk]").forEach(inp => inp.onchange = () => {
    const tx = o.text || (o.text = {}); const k = inp.dataset.tk;
    if (inp.tagName === "SELECT" || k === "text" || k === "font") tx[k] = inp.value; else { const v = num(inp.value); tx[k] = isFinite(v) ? v : 0; }
    changed();
  });
  box.querySelectorAll("[data-sk]").forEach(inp => inp.onchange = () => { const v = num(inp.value); o.shift = o.shift || [0, 0, 0]; o.shift[+inp.dataset.sk] = isFinite(v) ? v : 0; changed(); });
  box.querySelector("#cm-cmd-ok").onclick = () => closeCommand(true);
  box.querySelector("#cm-cmd-cancel").onclick = () => closeCommand(false);
  const fsb = box.querySelector("#cm-fs-op");
  if (fsb) fsb.onclick = () => applyFeedsOp(o);
  $("#cm-cmdwin").hidden = false;
  placeCmdWin();
}
const section = (i, active, done, label, body, sum) => `<section class="cw-sec${active ? " active" : ""}${done ? " done" : ""}${i === 0 ? " pick" : ""}" data-step="${i}">` +
  `<div class="cw-sec-head"><span class="cw-mark">${done ? "✓" : "●"}</span><span class="lbl">${esc(label)}</span><span class="sum">${esc(sum || "")}</span></div><div class="cw-sec-body">${body}</div></section>`;
function fieldHtml(f, obj, attr = "data-k") {
  const v = obj[f.k];
  if (f.kind === "sel") {
    let opts = f.opts;
    if (f.k === "of") opts = (CM.doc.operations || []).filter(x => x.id !== obj.id && !(OPS[x.type] || {}).supplemental && !(OPS[x.type] || {}).derived).map(x => [x.id, x.name]);
    return `<label class="cm-f"${f.title ? ` title="${esc(f.title)}"` : ""}>${esc(f.label)}<select ${attr}="${f.k}">${opts.map(([a, b]) => `<option value="${esc(a)}"${String(a) === String(v === null || v === undefined ? "auto" : v) ? " selected" : ""}>${esc(b)}</option>`).join("")}</select></label>`;
  }
  if (f.kind === "chk") return `<label class="check inline"${f.title ? ` title="${esc(f.title)}"` : ""}><input type="checkbox" ${attr}="${f.k}"${v ? " checked" : ""}> ${esc(f.label)}</label>`;
  if (f.kind === "txt") return `<label class="cm-f cm-wide"${f.title ? ` title="${esc(f.title)}"` : ""}>${esc(f.label)}<input type="text" class="cm-name" ${attr}="${f.k}" value="${esc(v == null ? "" : v)}"></label>`;
  if (f.kind === "area") return `<label class="cm-f cm-wide"${f.title ? ` title="${esc(f.title)}"` : ""}>${esc(f.label)}<textarea ${attr}="${f.k}" rows="5">${esc(v == null ? "" : v)}</textarea></label>`;
  return `<label class="cm-f"${f.title ? ` title="${esc(f.title)}"` : ""}>${esc(f.label)}<input type="text" class="numf" ${attr}="${f.k}" value="${v === null || v === undefined ? "" : esc(fmt(v, 6))}"></label>`;
}
function fieldsHtml(fields, obj, attr) { return `<div class="cm-grid">${(fields || []).map(f => fieldHtml(f, obj, attr)).join("")}</div>`; }
function baseDone(o, ot) {
  const b = ot.base || {};
  if ((o.faces || []).length || (o.edges || []).length || (o.points || []).length >= (b.points || 99)) return true;
  if (ot.text && o.text && o.text.text) return true;
  if (ot.sketch && o.sketch && o.sketch.name) return true;
  return !b.required;
}
function baseSummary(o) {
  const p = [];
  if ((o.faces || []).length) p.push(`${o.faces.length} face(s)`);
  if ((o.edges || []).length) p.push(`${o.edges.length} edge(s)`);
  if ((o.points || []).length) p.push(`${o.points.length} point(s)`);
  if (o.text && o.text.text) p.push(`text "${o.text.text}"`);
  if (o.sketch && o.sketch.name) p.push(`sketch ${o.sketch.name}`);
  return p.join(", ");
}
function baseHtml(o, ot, c) {
  const b = ot.base || {};
  let h = "";
  if (b.faces || b.edges || b.points) {
    const modes = [];
    if (b.faces) modes.push(["faces", "Faces"]);
    if (b.edges) modes.push(["edges", "Edges"]);
    if (b.points) modes.push(["points", "Points"]);
    const cur = c.mode || modes[0][0];
    if (!c.mode) c.mode = cur;
    h += `<p class="hint cw-hint">${esc(b.hint || "Click the geometry in the view")}</p>`;
    if (modes.length > 1) h += `<div class="cw-modes">${modes.map(([v, l]) => `<label class="check"><input type="radio" name="cm-mode" value="${v}"${v === cur ? " checked" : ""}> ${l}</label>`).join("")}</div>`;
    const chips = [];
    (o.faces || []).forEach((f, i) => chips.push(`<span class="cw-chip" data-prop="faces" data-i="${i}" title="Face at (${f.c.map(q => fmt(q, 3)).join(", ")})">Face ${i + 1} · ${fmt(f.area, 3)} mm^2<button type="button" data-cwdel="faces:${i}" title="Remove">×</button></span>`));
    (o.edges || []).forEach((e, i) => chips.push(`<span class="cw-chip" data-prop="edges" data-i="${i}" title="Edge at (${e.mid.map(q => fmt(q, 3)).join(", ")})">Edge ${i + 1} · ${fmt(e.len, 3)} mm<button type="button" data-cwdel="edges:${i}" title="Remove">×</button></span>`));
    (o.points || []).forEach((p, i) => chips.push(`<span class="cw-chip" data-prop="points" data-i="${i}">P${i + 1} (${fmt(p[0], 4)}, ${fmt(p[1], 4)})<button type="button" data-cwdel="points:${i}" title="Remove">×</button></span>`));
    if (chips.length) h += `<div class="cw-chips">${chips.join("")}<button type="button" class="cw-clear small" data-cwclear="1">Clear</button></div>`;
    if (b.points) h += `<div class="cm-grid">${[0, 1].map(i => `<label class="cm-f">P${i + 1} X<input type="text" class="numf" data-pt="${i}:0" value="${o.points && o.points[i] ? fmt(o.points[i][0], 6) : ""}"></label><label class="cm-f">P${i + 1} Y<input type="text" class="numf" data-pt="${i}:1" value="${o.points && o.points[i] ? fmt(o.points[i][1], 6) : ""}"></label>`).join("")}</div>`;
  }
  if (ot.sketch) h += `<div class="cm-grid"><label class="cm-f" title="A saved sketch of the project (Sketch tab), on the XY plane">Sketch<select data-sketch="1"><option value="">(none)</option>${CM.sketches.map(n => `<option value="${esc(n)}"${o.sketch && o.sketch.name === n ? " selected" : ""}>${esc(n)}</option>`).join("")}</select></label></div>`;
  if (ot.text) h += `<div class="pt-sec">Text</div>` + fieldsHtml(TEXT_FIELDS, o.text || {}, "data-tk");
  return h;
}
function bindBase(box, o, ot, c) {
  box.querySelectorAll("input[name=cm-mode]").forEach(r => r.onchange = () => { c.mode = r.value; draw(); });
  box.querySelectorAll("[data-cwdel]").forEach(b => b.onclick = e => { e.stopPropagation(); const [prop, i] = b.dataset.cwdel.split(":"); CM.chipHover = null; o[prop].splice(+i, 1); changed(); renderCommand(true); drawSelection(); });
  box.querySelectorAll(".cw-chip").forEach(ch => {
    ch.onmouseenter = () => { CM.chipHover = (o[ch.dataset.prop] || [])[+ch.dataset.i] || null; drawSelection(); };
    ch.onmouseleave = () => { CM.chipHover = null; drawSelection(); };
  });
  box.querySelectorAll("[data-cwclear]").forEach(b => b.onclick = () => { for (const k of ["faces", "edges", "points"]) if (o[k]) o[k] = []; changed(); renderCommand(true); drawSelection(); });
  box.querySelectorAll("[data-pt]").forEach(inp => inp.onchange = () => {
    const [i, j] = inp.dataset.pt.split(":").map(Number), v = num(inp.value);
    if (!isFinite(v)) return;
    o.points = o.points || [];
    while (o.points.length <= i) o.points.push([0, 0]);
    o.points[i][j] = v;
    changed(); drawSelection();
  });
  const sk = box.querySelector("[data-sketch]");
  if (sk) sk.onchange = () => { o.sketch = sk.value ? { name: sk.value } : null; changed(); renderCommand(true); };
}
function depthsHtml(o, r) {
  const hv = r && r.heights;
  return `<div class="cm-grid">${DEPTH_FIELDS.map(([k, l, t]) => `<label class="cm-f" title="${esc(t)}">${esc(l)}<input type="text" class="numf" data-k="${k}" value="${o[k] === null || o[k] === undefined ? "" : esc(fmt(o[k], 6))}" placeholder="${hv ? esc(fmt(hv[{ start_depth: "start", final_depth: "final", step_down: "step", finish_depth: "finish" }[k]], 5)) : ""}"></label>`).join("")}</div>
    <p class="hint">Part coordinates; empty fields take the default (shown greyed after a preview).</p>`;
}
function heightsHtml(o, r) {
  const hv = r && r.heights;
  return `<div class="cm-grid">${HEIGHT_FIELDS.map(([k, l, t]) => `<label class="cm-f" title="${esc(t)}">${esc(l)}<input type="text" class="numf" data-k="${k}" value="${o[k] === null || o[k] === undefined ? "" : esc(fmt(o[k], 6))}" placeholder="${hv ? esc(fmt(hv[{ clearance_height: "clearance", safe_height: "safe" }[k]], 5)) : ""}"></label>`).join("")}</div>`;
}
function opHtml(o, ot) {
  let h = "";
  if (!ot.supplemental && !ot.derived) {
    const tcs = (CM.doc.tools || []).map(t => { const b = bitOf(t.bit); return [t.id, `${t.id} ${t.name || ""}${b ? ` (${(CM.meta && CM.meta.shapes && CM.meta.shapes[b.shape]) || b.shape} ${fmt(b.d)} mm)` : ""}`]; });
    h += `<div class="cm-grid">${selField("Tool controller", "tc", o.tc, tcs.length ? tcs : [["", "(none)"]], ot.tools ? "Tool shapes: " + ot.tools.join(", ") : "")}</div>`;
  }
  if (o.type === "fixture") h += `<div class="cm-grid">${fieldHtml(ot.fields[0], o)}${[0, 1, 2].map(i => `<label class="cm-f" title="Estlcam: the coordinates shifted">Shift ${"XYZ"[i]} (mm)<input type="text" class="numf" data-sk="${i}" value="${fmt((o.shift || [0, 0, 0])[i], 6)}"></label>`).join("")}</div>`;
  else h += fieldsHtml(ot.fields, o);
  if (!ot.supplemental && !ot.derived) {
    h += `<div class="pt-sec">Feeds</div><div class="cm-grid">${numField("Feed (mm/min)", "feed", o.feed, "Empty: the tool controller")}${numField("Plunge (mm/min)", "plunge", o.plunge, "Empty: the tool controller")}${numField("Spindle (rpm)", "rpm", o.rpm, "Empty: the tool controller")}` +
      `<button type="button" class="small" id="cm-fs-op" title="Feed, plunge feed and spindle speed of this operation from the feeds and speeds calculator: the material of the stock, the tool bit, the step over (ae) and the step down (ap) of the operation">Calculate</button></div>`;
    const fo = CM.fsOp && CM.fsOp.id === o.id ? CM.fsOp.r : null;
    if (fo) h += `<p class="hint">ae ${fmt(fo.ae, 4)} mm, ap ${fmt(fo.ap, 4)} mm, chip load ${fmt(fo.fz_adj, 3)} mm/tooth, ${fmt(fo.power_kw, 3)} of ${fmt(fo.power_avail_kw, 3)} kW${fo.limited.length ? "; limited by " + fo.limited.join(", ") : ""}</p>` + fo.warnings.map(w => `<p class="hint err">${esc(w)}</p>`).join("");
  }
  if (!ot.supplemental) h += `<div class="cm-grid">${numField("Comment", "comment", o.comment || "", "Written in the G-code before the operation", "cm-name")}</div>`;
  return h;
}
function placeCmdWin() {
  const w = $("#cm-cmdwin"), v = $("#cm-view");
  if (!w || !v) return;
  let pos = CM.cmdPos;
  if (!pos) { try { pos = JSON.parse(localStorage.getItem("cm-cmdwin-pos") || "null"); } catch (e) { pos = null; } }
  pos = pos || { x: 12, y: 12 };
  const maxX = Math.max(0, v.clientWidth - w.offsetWidth - 4), maxY = Math.max(0, v.clientHeight - 60);
  pos = { x: Math.min(Math.max(0, pos.x), maxX), y: Math.min(Math.max(0, pos.y), maxY) };
  CM.cmdPos = pos;
  w.style.left = pos.x + "px"; w.style.top = pos.y + "px";
}
function bindDrag(headId, winId, key, onMove) {
  const head = $(headId);
  head.addEventListener("mousedown", e => {
    if (e.button !== 0 || e.target.closest("button")) return;
    const w = $(winId), x0 = e.clientX, y0 = e.clientY, p0 = { x: w.offsetLeft, y: w.offsetTop };
    const move = ev => onMove({ x: p0.x + ev.clientX - x0, y: p0.y + ev.clientY - y0 });
    const up = () => { window.removeEventListener("mousemove", move); window.removeEventListener("mouseup", up); try { localStorage.setItem(key, JSON.stringify({ x: $(winId).offsetLeft, y: $(winId).offsetTop })); } catch (err) { /* this session */ } };
    window.addEventListener("mousemove", move); window.addEventListener("mouseup", up);
    e.preventDefault();
  });
}

// ------------------------------------------------------------------ simulate, sanity check, G-code, template

async function runOps() {
  if (!hasSource()) { status("Choose a part first", true); return; }
  if (CM.cmd) closeCommand(true);
  if (CM.previewTimer) { clearTimeout(CM.previewTimer); CM.previewTimer = null; }
  const seq = ++CM.previewSeq;
  busy(true, "Computing the toolpaths...");
  try {
    const r = await postJSON("/api/cam/run", { cam: CM.doc, meshes: true });
    const res = await r.json();
    if (seq === CM.previewSeq) {
      CM.res = res; CM.resUpto = null;
      const bad = res.operations.filter(o => !o.ok);
      const t = res.operations.reduce((s, o) => s + (o.time_s || 0), 0);
      status(bad.length ? `${bad.length} operation(s) failed: ${bad[0].errors[0]}` : `${res.operations.length} operation(s), ${fmt(t / 60, 3)} min; ${fmt(res.left_mm3, 5)} mm^3 left${res.gone_mm3 > 0.05 ? `, ${fmt(res.gone_mm3, 5)} mm^3 of the part cut` : ""}`, !!bad.length);
      showSanity(res.sanity, false);
    }
  } catch (e) { CM.res = null; showErr(e); }
  busy(false);
  renderAll(); draw();
}
function showSanity(list, always) {
  const bad = (list || []).filter(x => x.level !== "info");
  if (!bad.length && !always) return;
  const box = $("#cm-props");
  CM.sel = null; renderTree();
  box.innerHTML = `<div class="row"><strong>Sanity check</strong></div>` + (list || []).map(x => `<div class="${x.level === "error" ? "cm-err" : x.level === "warning" ? "cm-warn" : "hint"}">${x.level}: ${esc(x.text)}</div>`).join("");
}
async function sanityCheck() {
  try {
    const r = await (await postJSON("/api/cam/sanity", { cam: CM.doc })).json();
    showSanity(r, true);
  } catch (e) { showErr(e); }
}
async function writeGcode(download) {
  if (!hasSource()) { status("Choose a part first", true); return; }
  const folder = download ? "-" : ($("#cm-folder").value.trim() || (CM.doc.output || {}).folder || "");
  busy(true, "Writing the G-code...");
  try {
    let r = await fetch("/api/cam/gcode", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ cam: CM.doc, folder }) });
    if (r.status === 409) {
      const j = await r.json();
      if (!confirm(`${j.exists} exists. Overwrite?`)) { busy(false); return; }
      r = await fetch("/api/cam/gcode", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ cam: CM.doc, folder, overwrite: true }) });
    }
    if (!r.ok) throw new Error((await r.json()).error || r.statusText);
    const ct = r.headers.get("content-type") || "";
    if (ct.includes("json")) {
      const j = await r.json();
      status(`Written ${j.written.join(", ")} (${j.lines} lines)`);
      if (window.projectRefreshDocs) window.projectRefreshDocs();
    } else {
      const blob = await r.blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      const nm = (CM.doc.output || {}).name || CM.doc.name || "cam";
      a.download = nm.replace(/[^A-Za-z0-9_\-.]+/g, "_") + (/\.(nc|gcode|tap|ngc)$/i.test(nm) ? "" : ".nc");
      a.click();
      status("G-code downloaded");
    }
  } catch (e) { showErr(e); }
  busy(false);
}
/** G-code of the selected operation (or the whole job) in the G-code window. */
async function inspectGcode() {
  if (!hasSource()) { status("Choose a part first", true); return; }
  const id = CM.cmd ? CM.cmd.id : CM.sel;
  const i = id ? opIndex(id) : -1;
  busy(true, "G-code...");
  try {
    const r = await (await postJSON("/api/cam/gcode", { cam: CM.doc, inspect: i >= 0 ? i : null })).json();
    $("#cm-gcodewin-title").textContent = `G-code: ${i >= 0 ? opOf(id).name : CM.doc.name} (${r.lines} lines)`;
    $("#cm-gcodebody").textContent = r.text;
    $("#cm-gcodewin").hidden = false;
  } catch (e) { showErr(e); }
  busy(false);
}
async function exportTemplate() {
  try {
    const t = await (await postJSON("/api/cam/template", { cam: CM.doc })).json();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(t, null, 1)], { type: "application/json" }));
    a.download = (CM.doc.name || "cam") + ".camtemplate.json";
    a.click();
    status("Template downloaded");
  } catch (e) { showErr(e); }
}
async function importTemplate(file) {
  try {
    const tpl = JSON.parse(await file.text());
    if (!confirm("Replace the setup sheet, tool controllers, stock, post-processor and operations of this job with the template? The base geometry of the operations is empty afterwards.")) return;
    const d = await (await postJSON("/api/cam/template", { cam: CM.doc, apply: tpl })).json();
    if (CM.cmd) { CM.cmd = null; $("#cm-cmdwin").hidden = true; }
    d.name = CM.doc.name;
    CM.doc = d; CM.sel = null;
    changed(); renderAll(); draw();
    status("Template applied");
  } catch (e) { showErr(e); }
}

// ------------------------------------------------------------------ tool bit library

function renderBits() {
  const box = $("#cm-tools");
  if (box.hidden) return;
  box.innerHTML = `<div class="fa-wide"><table class="cm-tools"><tr>${BIT_COLS.map(c => `<th>${esc(c[1])}</th>`).join("")}<th></th></tr>` +
    CM.bits.map((t, i) => `<tr data-i="${i}">` + BIT_COLS.map(([k]) => `<td>${k === "shape" ? `<select data-k="shape">${SHAPES.map(([v, l]) => `<option value="${v}"${t.shape === v ? " selected" : ""}>${l}</option>`).join("")}</select>` :
      k === "tool_material" ? `<select data-k="tool_material">${TOOL_MATS.map(([v, l]) => `<option value="${v}"${(t.tool_material || "carbide") === v ? " selected" : ""}>${l}</option>`).join("")}</select>` :
      `<input type="text" data-k="${k}" value="${esc(t[k] === null || t[k] === undefined ? "" : t[k])}">`}</td>`).join("") +
      `<td><button type="button" class="small" data-tdel="${i}" title="Delete the bit">×</button></td></tr>`).join("") + `</table></div>
    <div class="row"><button type="button" id="cm-tool-add" class="small">Add bit</button><button type="button" id="cm-tool-save" class="small primary" title="Save the tool bit library (config.json)">Save bits</button>
    <span class="hint">Dovetail: D is the large diameter, Angle the angle between the flank and the base plane, Cut. height the height of the flank. V bit: Angle the included angle, Tip the flat tip diameter. Bull nose: Corner r the corner radius.</span></div>`;
  box.querySelectorAll("tr[data-i] [data-k]").forEach(inp => inp.onchange = () => {
    const t = CM.bits[+inp.closest("tr").dataset.i], k = inp.dataset.k;
    if (k === "id" || k === "name" || k === "shape" || k === "tool_material") t[k] = inp.value.trim();
    else { const v = num(inp.value); t[k] = isFinite(v) ? v : null; }
  });
  box.querySelectorAll("button[data-tdel]").forEach(b => b.onclick = () => { CM.bits.splice(+b.dataset.tdel, 1); renderBits(); });
  $("#cm-tool-add").onclick = () => {
    let n = CM.bits.length + 1;
    while (CM.bits.some(t => t.id === "T" + n)) n++;
    CM.bits.push({ id: "T" + n, name: "", shape: "endmill", d: 6, corner: 0, angle: 0, tip: 0, height: 18, neck: 6, neck_length: 0, shank: 6, shank_length: 30, flutes: 2, tool_material: "carbide", feed: 800, plunge: 200, rpm: 12000 });
    renderBits();
  };
  $("#cm-tool-save").onclick = async () => {
    try {
      const r = await api("/api/cam/tools", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(CM.bits) });
      CM.bits = await r.json();
      status("Tool bit library saved");
      renderAll();
      schedulePreview(0);
    } catch (e) { showErr(e); }
  };
}
function bindToolsFold() {
  const h = $("#cm-tools-toggle"), box = $("#cm-tools");
  let open = false;
  try { open = localStorage.getItem("cm-tools-open") === "1"; } catch (e) { /* folded */ }
  const show = () => { box.hidden = !open; h.querySelector(".fold").textContent = open ? "▾" : "▸"; if (open) renderBits(); };
  h.onclick = () => { open = !open; try { localStorage.setItem("cm-tools-open", open ? "1" : "0"); } catch (e) { /* this session */ } show(); };
  show();
}

// ------------------------------------------------------------------ documents

let FM = null;
function refreshList() { if (FM) FM.refresh(); refreshSources(); }
async function refreshSources() {
  let parts = [];
  try { parts = await (await api("/api/part/list")).json(); } catch (e) { /* none */ }
  try { CM.sketches = await (await api("/api/sketch/list")).json(); } catch (e) { CM.sketches = []; }
  const s = CM.doc ? CM.doc.source || {} : {};
  $("#cm-source").innerHTML = `<option value="">(choose a part)</option>` + parts.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
  if (s.name && !parts.includes(s.name)) $("#cm-source").insertAdjacentHTML("beforeend", `<option value="${esc(s.name)}">${esc(s.name)} (missing)</option>`);
  $("#cm-source").value = s.name || "";
}
async function loadMeta() {
  try { CM.bits = await (await api("/api/cam/tools")).json(); } catch (e) { CM.bits = []; }
  try { CM.meta = await (await api("/api/cam/meta")).json(); CM.posts = CM.meta.posts; } catch (e) { CM.meta = null; CM.posts = []; }
}
function renderPost() {
  const sel = $("#cm-post"), cur = (CM.doc && CM.doc.post) || "estlcam";
  sel.innerHTML = CM.posts.map(p => `<option value="${esc(p.id)}"${p.id === cur ? " selected" : ""}>${esc(p.name)}</option>`).join("");
  $("#cm-outname").value = (CM.doc && CM.doc.output && CM.doc.output.name) || "";
  $("#cm-folder").value = (CM.doc && CM.doc.output && CM.doc.output.folder) || "";
}
async function loadDoc(d) {
  const b = blankDoc(d.name);
  for (const k of Object.keys(b)) if (d[k] === undefined) d[k] = b[k];
  if (CM.cmd) { CM.cmd = null; $("#cm-cmdwin").hidden = true; }
  CM.doc = d;
  CM.sel = null; CM.res = null; CM.hidden = {}; CM.placeRes = null;
  CM.dirty = false;
  if (CM.three) CM.three.zoomed = false;
  if (FM) FM.render();
  await refreshSources();
  renderAll();
  await loadGeometry();
}
async function saveDoc(name) {
  CM.doc.name = name;
  const r = await api("/api/cam/file/" + encodeURIComponent(name), { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(CM.doc) });
  const j = await r.json();
  CM.dirty = false;
  status("Saved " + j.path);
}

window.camShown = async function () {
  if (!CM.three) { initThree(); try { const f = JSON.parse(localStorage.getItem("cm-fold") || "null"); if (f) CM.fold = f; } catch (e) { /* folded as default */ } }
  if (!CM.meta) await loadMeta();
  if (!CM.doc) await loadDoc(blankDoc("cam"));
  refreshList();
  renderAll();
  setTimeout(resize3, 0);
};

(function bindCam() {
  document.addEventListener("keydown", e => {
    if ($("#tab-cam").hidden) return;
    if (e.key === "Escape") {
      if (!$("#cm-gcodewin").hidden) { $("#cm-gcodewin").hidden = true; return; }
      if (CM.zeroPick) { endZeroPick(); status("Machine zero pick cancelled"); return; }
      if (CM.cmd && CM.cmd.place && CM.cmd.pick) { CM.cmd.pick = null; renderCommand(true); draw(); return; }
      if (CM.cmd) closeCommand(true);
    }
  });
  $("#cm-source").onchange = () => {
    CM.doc.source = { type: "part", name: $("#cm-source").value };
    changed(false); loadGeometry();
  };
  document.querySelectorAll("#tab-cam [data-addop]").forEach(b => b.onclick = () => addOp(b.dataset.addop));
  document.querySelectorAll("#tab-cam [data-adddr]").forEach(b => b.onclick = () => addDressup(b.dataset.adddr));
  $("#cm-run").onclick = runOps;
  $("#cm-sanity").onclick = sanityCheck;
  $("#cm-post").onchange = () => { CM.doc.post = $("#cm-post").value; changed(false); renderTree(); };
  $("#cm-outname").onchange = () => { (CM.doc.output = CM.doc.output || {}).name = $("#cm-outname").value.trim(); changed(false); };
  $("#cm-folder").onchange = () => { (CM.doc.output = CM.doc.output || {}).folder = $("#cm-folder").value.trim(); changed(false); };
  $("#cm-gcode").onclick = () => writeGcode(false);
  $("#cm-gcode-dl").onclick = () => writeGcode(true);
  $("#cm-inspect").onclick = inspectGcode;
  $("#cm-inspect-tb").onclick = inspectGcode;
  $("#cm-place").onclick = openPlacement;
  $("#cm-zero").onclick = () => (CM.zeroPick ? endZeroPick() : startZeroPick());
  $("#cm-tpl-export").onclick = exportTemplate;
  $("#cm-tpl-import").onclick = () => $("#cm-tpl-file").click();
  $("#cm-tpl-file").onchange = () => { const f = $("#cm-tpl-file").files[0]; if (f) importTemplate(f); $("#cm-tpl-file").value = ""; };
  $("#cm-cmdwin-x").onclick = () => closeCommand(true);
  $("#cm-gcodewin-x").onclick = () => { $("#cm-gcodewin").hidden = true; };
  bindDrag("#cm-cmdwin-head", "#cm-cmdwin", "cm-cmdwin-pos", p => { CM.cmdPos = p; placeCmdWin(); });
  bindDrag("#cm-gcodewin-head", "#cm-gcodewin", "cm-gcodewin-pos", p => { const w = $("#cm-gcodewin"); w.style.left = Math.max(0, p.x) + "px"; w.style.top = Math.max(0, p.y) + "px"; });
  document.querySelectorAll("#tab-cam [data-cmview]").forEach(b => b.onclick = () => view(b.dataset.cmview));
  for (const id of ["#cm-edges", "#cm-axes", "#cm-showpart", "#cm-showstock", "#cm-showleft", "#cm-showpath", "#cm-showrapid", "#cm-showunder", "#cm-showhm"]) $(id).onchange = draw;
  bindToolsFold();
  FM = docFileMenu({ pre: "cm", type: "cam", label: "CAM job", pane: "#tab-cam", listUrl: "/api/cam/list",
    cur: () => (CM.doc ? { name: CM.doc.name, dirty: !!CM.dirty } : null),
    load: async name => loadDoc(await (await api("/api/cam/file/" + encodeURIComponent(name))).json()),
    save: saveDoc, blank: () => loadDoc(blankDoc("cam")), setName: name => { CM.doc.name = name; },
    folderHint: d => d.cam ? "empty: " + d.cam : "empty: download" });
  $("#cm-openstep").onclick = () => postJSON("/api/cam/open_folder", {}).catch(showErr);
  window.addEventListener("beforeunload", e => { if (CM.dirty) { e.preventDefault(); e.returnValue = ""; } });
})();

window.__cam = { CM, openCommand, closeCommand, addOp, addDressup, runOps, openPlacement, placePick, solvePlacement, setPlacement, applyFeedsAll, applyFeedsOp, opEngagement };
window.__camLoadNamed = async function (name) { await loadDoc(await (await api("/api/cam/file/" + encodeURIComponent(name))).json()); if (FM) FM.markSaved(name); };
window.__camSetName = name => { if (CM.doc) { CM.doc.name = name; if (FM) FM.markSaved(name); } };
window.__camRefresh = refreshList;
window.__camCurrent = () => (CM.doc ? { name: CM.doc.name, dirty: !!CM.dirty } : null);
